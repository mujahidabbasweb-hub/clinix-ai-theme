<?php
/**
 * Clinix AI theme functions (v2).
 *
 * @package clinix-ai
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CLINIX_VER', '2.0.1' );
define( 'CLINIX_FALLBACK', 'Thanks for contact pleas this question ask me from my admin of  Clinix AI' );

/* ==================================================================
 * 1. Settings (Appearance > Customize > Clinix AI Contact)
 * ================================================================*/
function clinix_opt( $key ) {
	$defaults = array(
		'phone_display' => '+92 321 9153891',
		'phone_tel'     => '+923219153891',
		'whatsapp'      => '923219153891',
		'email'         => get_option( 'admin_email' ),
		'address'       => 'Clinix AI Head Office, Pakistan',
		'map_query'     => 'Pakistan',
		'place'         => 'Pakistan',
		'hours'         => 'Monday to Saturday, 9:00 AM to 6:00 PM (PKT)',
		'linkedin'      => '',
		'facebook'      => '',
		'instagram'     => '',
	);
	$default = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	$value   = get_theme_mod( 'clinix_' . $key, $default );
	return ( '' === $value ) ? $default : $value;
}
function clinix_tel_url() {
	return 'tel:' . preg_replace( '/[^\d+]/', '', clinix_opt( 'phone_tel' ) );
}
function clinix_wa_url( $text = '' ) {
	$url = 'https://wa.me/' . preg_replace( '/\D/', '', clinix_opt( 'whatsapp' ) );
	return $text ? $url . '?text=' . rawurlencode( $text ) : $url;
}

add_action(
	'customize_register',
	function ( $wp_customize ) {
		$wp_customize->add_section( 'clinix_contact', array( 'title' => 'Clinix AI Contact', 'priority' => 30 ) );
		$fields = array(
			'phone_display' => 'Phone (display)',
			'phone_tel'     => 'Phone (dial format, e.g. +923219153891)',
			'whatsapp'      => 'WhatsApp number (digits only)',
			'email'         => 'Public email',
			'address'       => 'Office address',
			'map_query'     => 'Map search text (address or place)',
			'place'         => 'City / country for local SEO',
			'hours'         => 'Opening hours',
			'linkedin'      => 'LinkedIn URL',
			'facebook'      => 'Facebook URL',
			'instagram'     => 'Instagram URL',
		);
		foreach ( $fields as $id => $label ) {
			$wp_customize->add_setting( 'clinix_' . $id, array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
			$wp_customize->add_control( 'clinix_' . $id, array( 'label' => $label, 'section' => 'clinix_contact', 'type' => 'text' ) );
		}
	}
);

/* ==================================================================
 * 2. Theme setup, assets, head
 * ================================================================*/
add_action(
	'after_setup_theme',
	function () {
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
		add_theme_support( 'custom-logo', array( 'height' => 60, 'width' => 220, 'flex-width' => true, 'flex-height' => true ) );
		add_image_size( 'clinix-card', 900, 560, true );
		register_nav_menus( array( 'primary' => 'Primary Menu', 'footer' => 'Footer Menu' ) );
	}
);

add_action(
	'wp_enqueue_scripts',
	function () {
		wp_enqueue_style( 'clinix-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap', array(), null );
		wp_enqueue_style( 'clinix-style', get_stylesheet_uri(), array( 'clinix-fonts' ), CLINIX_VER );
		wp_enqueue_script( 'clinix-fx', get_template_directory_uri() . '/assets/js/fx.js', array(), CLINIX_VER, true );
		wp_enqueue_script( 'clinix-main', get_template_directory_uri() . '/assets/js/main.js', array(), CLINIX_VER, true );
		wp_enqueue_script( 'clinix-ai-agent', get_template_directory_uri() . '/ai-agent.js', array(), CLINIX_VER, true );
		wp_localize_script(
			'clinix-ai-agent',
			'ClinixAgent',
			array(
				'index'       => clinix_build_index(),
				'fallback'    => CLINIX_FALLBACK,
				'siteName'    => 'Clinix AI',
				'phoneTel'    => clinix_tel_url(),
				'phoneText'   => clinix_opt( 'phone_display' ),
				'waBase'      => clinix_wa_url(),
				'suggestions' => array( 'What is AI telehealth?', 'How does remote monitoring work?', 'Tell me about digital intake forms', 'Is my data secure?', 'What is your phone number?' ),
			)
		);
	}
);

add_action(
	'wp_head',
	function () {
		echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
		echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
		echo '<script>document.documentElement.className+=" js";</script>' . "\n";
		if ( ! has_site_icon() ) {
			echo '<link rel="icon" type="image/svg+xml" href="' . esc_url( get_theme_file_uri( 'assets/images/favicon.svg' ) ) . '">' . "\n";
			echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( get_theme_file_uri( 'assets/images/favicon-32.png' ) ) . '">' . "\n";
			echo '<link rel="apple-touch-icon" href="' . esc_url( get_theme_file_uri( 'assets/images/apple-touch-icon.png' ) ) . '">' . "\n";
		}
	},
	1
);

/* ==================================================================
 * 3. Page map: URLs, SEO titles, templates
 * ================================================================*/
function clinix_pages() {
	return array(
		'home'       => array( 'title' => 'Home', 'slug' => 'home', 'path' => 'home', 'legacy' => '', 'part' => 'home', 'parent' => '', 'tpl' => '', 'schema' => 'WebPage',
			'seo' => 'Clinix AI | AI Telehealth, Remote Patient Monitoring & Digital Intake', 'h1' => '', 'img' => '',
			'lead' => 'Clinix AI unites AI telehealth, remote patient monitoring and digital intake forms in one secure platform that syncs with your EHR in real time.' ),
		'about'      => array( 'title' => 'About Us', 'slug' => 'about-us', 'path' => 'about-us', 'legacy' => 'about', 'part' => 'about', 'parent' => '', 'tpl' => '', 'schema' => 'AboutPage',
			'seo' => 'About Clinix AI | Medical AI Ethics, Team & Security', 'h1' => 'Responsible AI, built with clinicians', 'img' => 'care-team.jpg',
			'lead' => 'Our vision, our medical AI ethics principles and the people and safeguards behind every Clinix AI deployment.' ),
		'services'   => array( 'title' => 'Services', 'slug' => 'services', 'path' => 'services', 'legacy' => '', 'part' => 'services', 'parent' => '', 'tpl' => '', 'schema' => 'CollectionPage',
			'seo' => 'Clinical Technology Services | Telehealth, RPM, Intake | Clinix AI', 'h1' => 'Clinical technology services for modern care teams', 'img' => 'lab-team.jpg',
			'lead' => 'From the first patient touchpoint to long-term monitoring, explore every solution Clinix AI delivers.' ),
		'features'   => array( 'title' => 'Features', 'slug' => 'features', 'path' => 'features', 'legacy' => '', 'part' => 'features', 'parent' => '', 'tpl' => '', 'schema' => 'WebPage',
			'seo' => 'Platform Features | Security, Real-Time Analytics & EHR Sync | Clinix AI', 'h1' => 'Platform security, live analytics and EHR sync', 'img' => 'neural-hand.jpg',
			'lead' => 'A closer look at the engineering that keeps patient data safe and care teams informed in real time.' ),
		'contact'    => array( 'title' => 'Contact Us', 'slug' => 'contact-us', 'path' => 'contact-us', 'legacy' => 'contact', 'part' => 'contact', 'parent' => '', 'tpl' => '', 'schema' => 'ContactPage',
			'seo' => 'Contact Clinix AI | Call, WhatsApp or Book a Demo', 'h1' => 'Talk to the Clinix AI team', 'img' => '',
			'lead' => 'Call, message us on WhatsApp or send the form. A real person replies.' ),
		'telehealth' => array( 'title' => 'AI Telehealth Care', 'slug' => 'ai-telehealth-care', 'path' => 'services/ai-telehealth-care', 'legacy' => 'telehealth', 'part' => 'telehealth', 'parent' => 'services', 'tpl' => 'page-telehealth.php', 'schema' => 'WebPage', 'service' => 'Telehealth',
			'seo' => 'AI Telehealth Care Platform | Secure Video Visits | Clinix AI', 'h1' => 'AI telehealth care that feels personal', 'img' => 'mri-consult.jpg',
			'lead' => 'Secure video visits with AI-prepared charts, live summaries and one-tap follow-up.' ),
		'rpm'        => array( 'title' => 'Remote Patient Monitoring', 'slug' => 'remote-patient-monitoring', 'path' => 'services/remote-patient-monitoring', 'legacy' => 'rpm', 'part' => 'rpm', 'parent' => 'services', 'tpl' => 'page-rpm.php', 'schema' => 'WebPage', 'service' => 'Remote patient monitoring',
			'seo' => 'Remote Patient Monitoring (RPM) Software | Clinix AI', 'h1' => 'Remote patient monitoring that catches change early', 'img' => 'robotic-therapy.jpg',
			'lead' => 'Connected devices, smart thresholds and 24/7 alerts so your team acts before a problem grows.' ),
		'intake'     => array( 'title' => 'Digital Intake Forms', 'slug' => 'digital-intake-forms', 'path' => 'services/digital-intake-forms', 'legacy' => 'intake', 'part' => 'intake', 'parent' => 'services', 'tpl' => 'page-intake.php', 'schema' => 'WebPage', 'service' => 'Digital patient intake',
			'seo' => 'Digital Patient Intake Forms | Paperless Check-In | Clinix AI', 'h1' => 'Digital intake forms patients actually finish', 'img' => 'care-team.jpg',
			'lead' => 'Replace clipboards with adaptive, accessible forms that flow straight into the chart.' ),
	);
}
function clinix_key_from_slug( $slug ) {
	foreach ( clinix_pages() as $key => $p ) {
		if ( $p['slug'] === $slug || ( $p['legacy'] && $p['legacy'] === $slug ) ) {
			return $key;
		}
	}
	return '';
}
function clinix_url( $key ) {
	$pages = clinix_pages();
	if ( 'articles' === $key ) {
		$id = (int) get_option( 'page_for_posts' );
		return $id ? get_permalink( $id ) : home_url( '/articles/' );
	}
	if ( ! isset( $pages[ $key ] ) || 'home' === $key ) {
		return home_url( '/' );
	}
	$page = get_page_by_path( $pages[ $key ]['path'] );
	return $page ? get_permalink( $page ) : home_url( '/' . $pages[ $key ]['path'] . '/' );
}
function clinix_render_page( $key ) {
	if ( 'home' !== $key ) {
		clinix_page_hero( $key );
	}
	$pages = clinix_pages();
	get_template_part( 'template-parts/content', $pages[ $key ]['part'] );
	if ( is_singular( 'page' ) ) {
		while ( have_posts() ) {
			the_post();
			if ( '' !== trim( get_the_content() ) ) {
				echo '<section class="section"><div class="container prose">';
				the_content();
				echo '</div></section>';
			}
		}
	}
}

/* ==================================================================
 * 4. Setup on activation / upgrade: pages, permalinks, menu, samples
 * ================================================================*/
function clinix_seed_articles() {
	return array(
		array( 'What Is AI Telehealth? A Plain-English Guide for Clinics', 'what-is-ai-telehealth', 'Telehealth', 'AI telehealth combines secure video visits with automated preparation and documentation. Here is how it works and what to look for.', 'brain-network.jpg',
			'<p>AI telehealth is virtual care where software helps with the work around the visit: preparing the chart, drafting the note and scheduling follow-up. The clinician stays in charge of every decision.</p><h2>How AI telehealth works</h2><p>Before the call, the platform gathers history, recent results and open issues into a short summary. During the call, patients and clinicians meet over encrypted video. Afterwards, a draft note and suggested orders are ready for review.</p><h2>Benefits for clinics</h2><ul><li>Less time spent on documentation.</li><li>Shorter waits and fewer missed appointments.</li><li>A complete record saved straight to the EHR.</li></ul><h2>What to look for</h2><p>Choose a platform with end-to-end encryption, role-based access, audit logs and clear human review of every AI suggestion. Ask how it connects to your EHR and how patients join, ideally from a simple link with no app to install.</p><h2>Getting started</h2><p>Start with one clinic or service line, measure time saved, then expand. Clinix AI can walk you through a pilot plan.</p>' ),
		array( 'Remote Patient Monitoring: How It Works and Who Benefits', 'remote-patient-monitoring-how-it-works', 'Remote Monitoring', 'Remote patient monitoring tracks readings from home and alerts your team to change. Learn the basics, devices and workflow.', 'robotic-therapy.jpg',
			'<p>Remote patient monitoring (RPM) lets care teams follow a patient\'s health between visits. Connected devices send readings to a dashboard, and smart thresholds flag anything that needs attention.</p><h2>Common devices</h2><p>Blood pressure cuffs, glucose meters, pulse oximeters, thermometers and smart scales are the most common. Most connect by Bluetooth or cellular and send readings automatically.</p><h2>Who benefits</h2><ul><li>People living with chronic conditions.</li><li>Patients recovering after surgery or hospital stays.</li><li>Older adults who want to stay independent at home.</li></ul><h2>From reading to response</h2><p>When a reading crosses a personal threshold, the responsible clinician is alerted by app, SMS or email. They can call the patient, adjust a plan or book a visit.</p><h2>Making it work</h2><p>Success depends on simple devices, clear thresholds and a defined response process. Fewer, smarter alerts keep teams focused on the patients who need them most.</p>' ),
		array( 'Why Digital Intake Forms Beat Paper in Every Waiting Room', 'digital-intake-forms-vs-paper', 'Digital Intake', 'Digital intake forms save time, reduce errors and protect data. See how they compare with clipboards and what to include.', 'care-team.jpg',
			'<p>Paper intake forms slow check-in, hide errors in handwriting and create privacy risks. Digital intake forms solve all three.</p><h2>Faster, calmer check-in</h2><p>Patients complete forms at home on a phone or computer. Front-desk staff stop retyping and waiting rooms stay quieter.</p><h2>Cleaner data</h2><p>Typed answers, required fields and adaptive questions reduce missing or unreadable information, and answers flow directly into the record.</p><h2>Better privacy</h2><p>Encrypted forms and role-based access are safer than clipboards left on a counter.</p><h2>What to include</h2><ul><li>Demographics and contact details.</li><li>Reason for visit and current symptoms.</li><li>Medications and allergies.</li><li>Digital consent with a time stamp.</li></ul><p>Make forms accessible with clear labels, large touch targets and screen-reader support.</p>' ),
		array( 'Medical AI Ethics: Six Principles Every Clinic Should Ask About', 'medical-ai-ethics-principles', 'AI Ethics', 'Before adopting AI in care, ask about human oversight, transparency, privacy, fairness, safety and accountability.', 'brain-network.jpg',
			'<p>Healthcare AI should support clinicians, not replace them. These six principles help clinics evaluate any AI vendor.</p><h2>1. Human in the loop</h2><p>A licensed professional should review AI suggestions before they affect care.</p><h2>2. Transparency</h2><p>Patients and staff should know when AI is used and what information it relies on.</p><h2>3. Privacy by design</h2><p>Collect only what is needed, encrypt it and never sell patient data.</p><h2>4. Fairness</h2><p>Models should be tested across age, gender and background to reduce unequal outcomes.</p><h2>5. Safety</h2><p>Urgent cases must have a clear route to a person.</p><h2>6. Accountability</h2><p>Audit logs should record who saw, changed or approved each AI-assisted action.</p>' ),
		array( 'EHR Integration Basics: HL7, FHIR and What They Mean for You', 'ehr-integration-hl7-fhir-basics', 'Interoperability', 'HL7 and FHIR are the standards that let health systems share data. Understand the basics before you integrate.', 'neural-hand.jpg',
			'<p>An electronic health record (EHR) is only as useful as the data flowing in and out of it. Standards such as HL7 and FHIR make that exchange possible.</p><h2>What is HL7?</h2><p>HL7 v2 is a long-established messaging standard used by hospitals and labs to send admissions, results and orders between systems.</p><h2>What is FHIR?</h2><p>FHIR is a newer, web-friendly standard that exposes patient data as simple resources, which makes modern apps easier to connect.</p><h2>Why it matters</h2><ul><li>One source of truth across tools.</li><li>No double entry for staff.</li><li>Faster, safer information for clinicians.</li></ul><h2>Planning an integration</h2><p>List the data you need, confirm which standards your EHR supports and test in a safe environment before going live. Legacy systems can often connect through secure gateways.</p>' ),
	);
}

function clinix_setup_site() {
	global $wp_rewrite;
	$pages = clinix_pages();
	$ids   = array();
	$order = array( 'home', 'about', 'services', 'telehealth', 'rpm', 'intake', 'features', 'contact' );
	foreach ( $order as $i => $key ) {
		$p         = $pages[ $key ];
		$parent_id = ( $p['parent'] && isset( $ids[ $p['parent'] ] ) ) ? (int) $ids[ $p['parent'] ] : 0;
		$page      = get_page_by_path( $p['path'] );
		if ( ! $page && $p['legacy'] ) {
			$page = get_page_by_path( $p['legacy'] );
		}
		if ( $page ) {
			$ids[ $key ] = $page->ID;
			if ( $page->post_name !== $p['slug'] || (int) $page->post_parent !== $parent_id ) {
				wp_update_post( array( 'ID' => $page->ID, 'post_name' => $p['slug'], 'post_parent' => $parent_id ) );
			}
		} else {
			$new = wp_insert_post( array( 'post_title' => $p['title'], 'post_name' => $p['slug'], 'post_type' => 'page', 'post_status' => 'publish', 'post_parent' => $parent_id, 'menu_order' => $i, 'post_content' => '' ) );
			if ( is_wp_error( $new ) || ! $new ) {
				continue;
			}
			$ids[ $key ] = $new;
		}
		if ( $p['tpl'] ) {
			update_post_meta( $ids[ $key ], '_wp_page_template', $p['tpl'] );
		}
	}
	// Articles page (posts page).
	$art = get_page_by_path( 'articles' );
	if ( ! $art ) {
		$aid = wp_insert_post( array( 'post_title' => 'Articles', 'post_name' => 'articles', 'post_type' => 'page', 'post_status' => 'publish', 'menu_order' => 7 ) );
	} else {
		$aid = $art->ID;
	}
	if ( $aid && ! is_wp_error( $aid ) ) {
		update_option( 'page_for_posts', $aid );
		$ids['articles'] = $aid;
	}
	if ( ! empty( $ids['home'] ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $ids['home'] );
	}

	// SEO-friendly permalinks.
	$structure = get_option( 'permalink_structure' );
	if ( ! $structure || false === strpos( $structure, '%postname%' ) ) {
		$wp_rewrite->set_permalink_structure( '/%postname%/' );
	}
	if ( ! get_option( 'category_base' ) ) {
		$wp_rewrite->set_category_base( 'topics' );
	}

	// Menu (rebuilt on each upgrade).
	$name = 'Clinix Primary';
	$old  = wp_get_nav_menu_object( $name );
	if ( $old ) {
		wp_delete_nav_menu( $old->term_id );
	}
	$menu_id = wp_create_nav_menu( $name );
	if ( ! is_wp_error( $menu_id ) ) {
		$items = array();
		foreach ( array( 'home', 'about', 'services', 'telehealth', 'rpm', 'intake', 'features', 'articles', 'contact' ) as $key ) {
			if ( empty( $ids[ $key ] ) ) {
				continue;
			}
			$label = ( 'articles' === $key ) ? 'Articles' : $pages[ $key ]['title'];
			$args  = array( 'menu-item-title' => $label, 'menu-item-object' => 'page', 'menu-item-object-id' => $ids[ $key ], 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' );
			if ( isset( $pages[ $key ] ) && $pages[ $key ]['parent'] && isset( $items[ $pages[ $key ]['parent'] ] ) ) {
				$args['menu-item-parent-id'] = $items[ $pages[ $key ]['parent'] ];
			}
			$items[ $key ] = wp_update_nav_menu_item( $menu_id, 0, $args );
		}
		$locs            = get_theme_mod( 'nav_menu_locations', array() );
		$locs['primary'] = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locs );
	}

	// Sample content (once).
	if ( ! get_option( 'clinix_seeded' ) ) {
		$author = get_current_user_id() ? get_current_user_id() : 1;
		foreach ( clinix_seed_articles() as $n => $a ) {
			if ( get_page_by_path( $a[1], OBJECT, 'post' ) ) {
				continue;
			}
			$term = term_exists( $a[2], 'category' );
			if ( ! $term ) {
				$term = wp_insert_term( $a[2], 'category' );
			}
			$cat = is_array( $term ) ? (int) $term['term_id'] : 0;
			$pid = wp_insert_post( array(
				'post_title'    => $a[0],
				'post_name'     => $a[1],
				'post_excerpt'  => $a[3],
				'post_content'  => $a[5],
				'post_status'   => 'publish',
				'post_type'     => 'post',
				'post_author'   => $author,
				'post_category' => $cat ? array( $cat ) : array(),
				'post_date'     => gmdate( 'Y-m-d H:i:s', time() - ( $n + 1 ) * 4 * DAY_IN_SECONDS ),
			) );
			if ( $pid && ! is_wp_error( $pid ) ) {
				update_post_meta( $pid, '_clinix_hero_img', $a[4] );
			}
		}
		$tests = array(
			array( 'Clinic Operations Manager', 'Intake used to take our front desk half the morning. Now patients arrive with everything done and the chart is ready.', 'Multi-doctor family clinic' ),
			array( 'Consultant Physician', 'The monitoring dashboard shows me who needs a call today. I stopped chasing readings and started acting on them.', 'Chronic care programme' ),
			array( 'Telehealth Lead', 'Video visits feel calm and personal, and the summary lands in the record before the patient has hung up.', 'Specialist outpatient centre' ),
		);
		foreach ( $tests as $t ) {
			wp_insert_post( array( 'post_type' => 'clinix_testimonial', 'post_status' => 'publish', 'post_title' => $t[0], 'post_content' => $t[1], 'post_excerpt' => $t[2] ) );
		}
		update_option( 'clinix_seeded', '1' );
	}

	clinix_flush_index();
	update_option( 'clinix_setup_ver', CLINIX_VER );
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'clinix_setup_site' );
add_action(
	'admin_init',
	function () {
		if ( current_user_can( 'manage_options' ) && get_option( 'clinix_setup_ver' ) !== CLINIX_VER ) {
			clinix_setup_site();
		}
		if ( isset( $_GET['clinix_dismiss'] ) && current_user_can( 'manage_options' ) && check_admin_referer( 'clinix_dismiss' ) ) { // phpcs:ignore
			update_option( 'clinix_seeded', 'done' );
			wp_safe_redirect( admin_url() );
			exit;
		}
	}
);
add_action(
	'admin_notices',
	function () {
		if ( '1' !== get_option( 'clinix_seeded' ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$url = wp_nonce_url( admin_url( 'index.php?clinix_dismiss=1' ), 'clinix_dismiss' );
		echo '<div class="notice notice-info"><p><strong>Clinix AI:</strong> sample articles and testimonials were added so the site looks complete. Edit or delete them under <em>Posts</em> and <em>Testimonials</em> before you go live. <a href="' . esc_url( $url ) . '">Dismiss</a></p></div>';
	}
);

function clinix_fallback_menu() {
	$p = clinix_pages();
	echo '<ul class="menu">';
	foreach ( array( 'home', 'about', 'services', 'features', 'articles', 'contact' ) as $key ) {
		$label = isset( $p[ $key ] ) ? $p[ $key ]['title'] : 'Articles';
		echo '<li><a href="' . esc_url( clinix_url( $key ) ) . '">' . esc_html( $label ) . '</a></li>';
	}
	echo '</ul>';
}

/* Legacy URL redirects (v1 slugs -> v2 slugs). */
add_action(
	'template_redirect',
	function () {
		if ( ! is_404() ) {
			return;
		}
		$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '';
		$last = basename( untrailingslashit( (string) $path ) );
		foreach ( array( 'telehealth', 'rpm', 'intake', 'about', 'contact' ) as $legacy ) {
			if ( $last === $legacy ) {
				$key = clinix_key_from_slug( $legacy );
				if ( $key ) {
					wp_safe_redirect( clinix_url( $key ), 301 );
					exit;
				}
			}
		}
	}
);

/* ==================================================================
 * 5. Custom post types: testimonials + inquiries
 * ================================================================*/
add_action(
	'init',
	function () {
		register_post_type( 'clinix_testimonial', array(
			'labels'       => array( 'name' => 'Testimonials', 'singular_name' => 'Testimonial', 'add_new_item' => 'Add testimonial' ),
			'public'       => false,
			'show_ui'      => true,
			'menu_icon'    => 'dashicons-format-quote',
			'supports'     => array( 'title', 'editor', 'excerpt', 'page-attributes' ),
			'show_in_rest' => true,
		) );
		register_post_type( 'clinix_inquiry', array(
			'labels'          => array( 'name' => 'Inquiries', 'singular_name' => 'Inquiry' ),
			'public'          => false,
			'show_ui'         => true,
			'menu_icon'       => 'dashicons-email-alt',
			'supports'        => array( 'title', 'editor' ),
			'capability_type' => 'post',
			'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
			'map_meta_cap'    => true,
		) );
		add_rewrite_rule( '^llms\.txt$', 'index.php?clinix_llms=1', 'top' );
	}
);
add_filter( 'query_vars', function ( $v ) {
	$v[] = 'clinix_llms';
	return $v;
} );

/* ==================================================================
 * 6. Forms (contact + intake)
 * ================================================================*/
function clinix_form_notice() {
	global $clinix_indexing;
	if ( ! empty( $clinix_indexing ) ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$status = isset( $_GET['clinix_status'] ) ? sanitize_key( wp_unslash( $_GET['clinix_status'] ) ) : '';
	$msgs   = array(
		'sent'    => array( 'ok', 'Thank you. Your message was sent and our team will reply shortly.' ),
		'invalid' => array( 'err', 'Please check the form: name, a valid email and the required fields must be completed.' ),
		'wait'    => array( 'err', 'Please wait a few seconds before sending another message.' ),
		'error'   => array( 'err', 'Your session expired. Please reload the page and try again.' ),
	);
	if ( $status && isset( $msgs[ $status ] ) ) {
		echo '<div id="form-status" class="notice notice--' . esc_attr( $msgs[ $status ][0] ) . '" role="status">' . esc_html( $msgs[ $status ][1] ) . '</div>';
	}
}

function clinix_handle_form() {
	$back = wp_get_referer();
	$back = $back ? remove_query_arg( 'clinix_status', $back ) : home_url( '/' );
	$go   = function ( $status ) use ( $back ) {
		wp_safe_redirect( add_query_arg( 'clinix_status', $status, $back ) . '#form-status' );
		exit;
	};
	$nonce = isset( $_POST['clinix_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['clinix_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'clinix_form' ) ) {
		$go( 'error' );
	}
	if ( ! empty( $_POST['website'] ) ) {
		$go( 'sent' );
	}
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'x';
	$key = 'clinix_rl_' . md5( $ip );
	if ( get_transient( $key ) ) {
		$go( 'wait' );
	}
	$type = ( isset( $_POST['form_type'] ) && 'intake' === $_POST['form_type'] ) ? 'intake' : 'contact';
	$f    = function ( $n, $multi = false ) {
		if ( ! isset( $_POST[ $n ] ) ) {
			return '';
		}
		$v = wp_unslash( $_POST[ $n ] );
		return $multi ? sanitize_textarea_field( $v ) : sanitize_text_field( $v );
	};
	$name    = $f( 'name' );
	$email   = sanitize_email( $f( 'email' ) );
	$phone   = $f( 'phone' );
	$message = $f( 'message', true );
	if ( '' === $name || ! is_email( $email ) || ( 'contact' === $type && '' === $message ) ) {
		$go( 'invalid' );
	}
	$lines = array( "Type: $type", "Name: $name", "Email: $email", "Phone: $phone" );
	if ( 'intake' === $type ) {
		if ( empty( $_POST['consent'] ) ) {
			$go( 'invalid' );
		}
		$lines[] = 'Date of birth: ' . $f( 'dob' );
		$lines[] = 'Reason for visit: ' . $f( 'reason' );
		$lines[] = 'Symptoms: ' . $f( 'symptoms', true );
		$lines[] = 'Medications: ' . $f( 'meds', true );
		$lines[] = 'Allergies: ' . $f( 'allergies', true );
		$lines[] = 'Consent given: yes';
	} else {
		$lines[] = "Message:\n" . $message;
	}
	$body = implode( "\n", $lines );
	wp_insert_post( array( 'post_type' => 'clinix_inquiry', 'post_status' => 'private', 'post_title' => ucfirst( $type ) . ' - ' . $name, 'post_content' => $body ) );
	wp_mail( get_option( 'admin_email' ), '[Clinix AI] New ' . $type . ' enquiry from ' . $name, $body, array( 'Reply-To: ' . $name . ' <' . $email . '>' ) );
	set_transient( $key, 1, 30 );
	$go( 'sent' );
}
add_action( 'admin_post_nopriv_clinix_form', 'clinix_handle_form' );
add_action( 'admin_post_clinix_form', 'clinix_handle_form' );

/* ==================================================================
 * 7. AI agent knowledge index (RAG)
 * ================================================================*/
function clinix_chunk_html( $html, $page_title, $url ) {
	$html = preg_replace( '#<(script|style|svg|form|noscript|button|nav)\b[^>]*>.*?</\1>#is', '', $html );
	if ( '' === trim( wp_strip_all_tags( $html ) ) ) {
		return array();
	}
	if ( ! class_exists( 'DOMDocument' ) ) {
		$t = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $html ) ) );
		return array( array( 't' => $page_title, 'h' => $page_title, 'x' => $t, 'u' => $url ) );
	}
	libxml_use_internal_errors( true );
	$dom = new DOMDocument();
	$dom->loadHTML( '<?xml encoding="utf-8" ?><div>' . $html . '</div>' );
	libxml_clear_errors();
	$xp      = new DOMXPath( $dom );
	$nodes   = $xp->query( '//h1|//h2|//h3|//h4|//summary|//p|//li[not(.//p)]|//address|//figcaption|//dt|//dd' );
	$out     = array();
	$heading = $page_title;
	$buf     = '';
	$flush   = function () use ( &$out, &$heading, &$buf, $page_title, $url ) {
		$t = trim( preg_replace( '/\s+/u', ' ', $buf ) );
		if ( strlen( $t ) >= 20 ) {
			$out[] = array( 't' => $page_title, 'h' => $heading, 'x' => $t, 'u' => $url );
		}
		$buf = '';
	};
	if ( $nodes ) {
		foreach ( $nodes as $n ) {
			$txt = trim( preg_replace( '/\s+/u', ' ', $n->textContent ) );
			if ( '' === $txt ) {
				continue;
			}
			if ( in_array( $n->nodeName, array( 'h1', 'h2', 'h3', 'h4', 'summary' ), true ) ) {
				$flush();
				$heading = $txt;
				continue;
			}
			if ( ! preg_match( '/[.!?:]$/u', $txt ) ) {
				$txt .= '.';
			}
			$buf .= $txt . ' ';
			if ( strlen( $buf ) > 650 ) {
				$flush();
			}
		}
	}
	$flush();
	return $out;
}

function clinix_build_index() {
	$cache_key = 'clinix_ai_index_' . CLINIX_VER;
	$cached    = get_transient( $cache_key );
	if ( is_array( $cached ) && $cached ) {
		return $cached;
	}
	global $clinix_indexing;
	$clinix_indexing = true;
	$chunks          = array();
	$known           = array();
	foreach ( clinix_pages() as $key => $p ) {
		$url = clinix_url( $key );
		ob_start();
		echo '<h2>' . esc_html( $p['h1'] ? $p['h1'] : $p['title'] ) . '</h2><p>' . esc_html( $p['lead'] ) . '</p>';
		get_template_part( 'template-parts/content', $p['part'] );
		$html = ob_get_clean();
		$page = get_page_by_path( $p['path'] );
		if ( $page ) {
			$known[] = $page->ID;
			if ( '' !== trim( $page->post_content ) ) {
				$html .= wpautop( do_blocks( $page->post_content ) );
			}
		}
		$chunks = array_merge( $chunks, clinix_chunk_html( $html, $p['title'], $url ) );
	}
	$art = (int) get_option( 'page_for_posts' );
	if ( $art ) {
		$known[] = $art;
	}
	$facts    = 'Phone and call: ' . clinix_opt( 'phone_display' ) . '. WhatsApp number: ' . clinix_opt( 'phone_display' ) . '. Email: ' . clinix_opt( 'email' ) . '. Address and office location: ' . clinix_opt( 'address' ) . '. Opening hours and availability: ' . clinix_opt( 'hours' ) . '.';
	$chunks[] = array( 't' => 'Contact Us', 'h' => 'Contact Clinix AI', 'x' => $facts, 'u' => clinix_url( 'contact' ) );
	$others   = get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => 'publish', 'posts_per_page' => 200, 'post__not_in' => $known ) );
	foreach ( $others as $post ) {
		$html   = '<h2>' . esc_html( get_the_title( $post ) ) . '</h2>' . wpautop( do_blocks( $post->post_content ) );
		$chunks = array_merge( $chunks, clinix_chunk_html( $html, get_the_title( $post ), get_permalink( $post ) ) );
	}
	$clinix_indexing = false;
	set_transient( $cache_key, $chunks, DAY_IN_SECONDS );
	return $chunks;
}
function clinix_flush_index() {
	delete_transient( 'clinix_ai_index_' . CLINIX_VER );
}
add_action( 'save_post', 'clinix_flush_index' );
add_action( 'deleted_post', 'clinix_flush_index' );
add_action( 'customize_save_after', 'clinix_flush_index' );
add_action( 'switch_theme', 'clinix_flush_index' );

/* ==================================================================
 * 8. SEO / AEO / GEO
 * ================================================================*/
function clinix_seo_active() {
	return defined( 'WPSEO_VERSION' ) || class_exists( 'RankMath' ) || defined( 'AIOSEO_VERSION' );
}

add_filter( 'document_title_separator', function () {
	return '|';
} );
add_filter( 'pre_get_document_title', function ( $title ) {
	if ( clinix_seo_active() ) {
		return $title;
	}
	$pages = clinix_pages();
	if ( is_front_page() ) {
		return $pages['home']['seo'];
	}
	if ( is_page() ) {
		$key = clinix_key_from_slug( get_post_field( 'post_name', get_queried_object_id() ) );
		if ( $key ) {
			return $pages[ $key ]['seo'];
		}
	}
	if ( is_home() ) {
		return 'Articles on AI Healthcare Technology | Clinix AI';
	}
	return $title;
} );
add_filter( 'wp_robots', function ( $r ) {
	$r['max-image-preview'] = 'large';
	$r['max-snippet']       = '-1';
	$r['max-video-preview'] = '-1';
	return $r;
} );

function clinix_post_image_url( $post_id = 0 ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	$url     = get_the_post_thumbnail_url( $post_id, 'large' );
	if ( $url ) {
		return $url;
	}
	$hero = get_post_meta( $post_id, '_clinix_hero_img', true );
	if ( ! $hero ) {
		$set  = array( 'brain-network.jpg', 'mri-consult.jpg', 'lab-team.jpg', 'neural-hand.jpg', 'care-team.jpg', 'robotic-therapy.jpg', 'robot-flower.jpg', 'futuristic-clinic.jpg' );
		$hero = $set[ $post_id % count( $set ) ];
	}
	return get_theme_file_uri( 'assets/images/' . $hero );
}

function clinix_reading_time( $post = null ) {
	$post  = get_post( $post );
	$words = str_word_count( wp_strip_all_tags( $post->post_content ) );
	return max( 1, (int) ceil( $words / 220 ) );
}

function clinix_crumbs() {
	$pages  = clinix_pages();
	$crumbs = array( array( 'Home', home_url( '/' ) ) );
	if ( is_front_page() ) {
		return $crumbs;
	}
	if ( is_page() ) {
		$key = clinix_key_from_slug( get_post_field( 'post_name', get_queried_object_id() ) );
		if ( $key && $pages[ $key ]['parent'] ) {
			$crumbs[] = array( $pages[ $pages[ $key ]['parent'] ]['title'], clinix_url( $pages[ $key ]['parent'] ) );
		}
		$crumbs[] = array( get_the_title( get_queried_object_id() ), get_permalink( get_queried_object_id() ) );
	} elseif ( is_singular( 'post' ) ) {
		$crumbs[] = array( 'Articles', clinix_url( 'articles' ) );
		$cats     = get_the_category();
		if ( $cats ) {
			$crumbs[] = array( $cats[0]->name, get_category_link( $cats[0] ) );
		}
		$crumbs[] = array( get_the_title(), get_permalink() );
	} elseif ( is_home() ) {
		$crumbs[] = array( 'Articles', clinix_url( 'articles' ) );
	} elseif ( is_category() ) {
		$crumbs[] = array( 'Articles', clinix_url( 'articles' ) );
		$crumbs[] = array( single_cat_title( '', false ), get_category_link( get_queried_object_id() ) );
	}
	return $crumbs;
}

function clinix_current_desc() {
	$default = 'Clinix AI is a HealthTech platform for AI telehealth, remote patient monitoring and digital intake forms, synced with your EHR.';
	$pages   = clinix_pages();
	if ( is_singular( 'post' ) ) {
		$d = has_excerpt() ? get_the_excerpt() : wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_the_content() ) ), 30 );
		return wp_strip_all_tags( $d );
	}
	if ( is_page() ) {
		$key = clinix_key_from_slug( get_post_field( 'post_name', get_queried_object_id() ) );
		if ( $key ) {
			return $pages[ $key ]['lead'];
		}
	}
	if ( is_front_page() ) {
		return $pages['home']['lead'];
	}
	if ( is_home() ) {
		return 'Practical articles on AI telehealth, remote patient monitoring, digital intake, interoperability and medical AI ethics from the Clinix AI team.';
	}
	if ( is_category() && category_description() ) {
		return wp_strip_all_tags( category_description() );
	}
	return $default;
}

function clinix_canonical_url() {
	if ( is_front_page() ) {
		return home_url( '/' );
	}
	if ( is_home() ) {
		$u = clinix_url( 'articles' );
		return get_query_var( 'paged' ) > 1 ? get_pagenum_link( get_query_var( 'paged' ) ) : $u;
	}
	if ( is_category() || is_tag() ) {
		return get_term_link( get_queried_object() );
	}
	return '';
}

add_action(
	'wp_head',
	function () {
		if ( clinix_seo_active() ) {
			return;
		}
		$desc  = clinix_current_desc();
		$title = wp_get_document_title();
		$img   = is_singular( 'post' ) ? clinix_post_image_url( get_the_ID() ) : get_theme_file_uri( 'assets/images/og-image.jpg' );
		$canon = clinix_canonical_url();
		if ( $canon && ! is_wp_error( $canon ) ) {
			echo '<link rel="canonical" href="' . esc_url( $canon ) . '">' . "\n";
		}
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		echo '<meta property="og:site_name" content="Clinix AI">' . "\n";
		echo '<meta property="og:locale" content="en_US">' . "\n";
		echo '<meta property="og:type" content="' . ( is_singular( 'post' ) ? 'article' : 'website' ) . '">' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
		echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n";
		if ( ! is_singular( 'post' ) ) {
			echo '<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">' . "\n";
		}
		if ( is_singular( 'post' ) ) {
			echo '<meta property="article:published_time" content="' . esc_attr( get_the_date( 'c' ) ) . '">' . "\n";
			echo '<meta property="article:modified_time" content="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . "\n";
		}
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
		echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
		echo '<meta name="twitter:description" content="' . esc_attr( $desc ) . '">' . "\n";
		echo '<meta name="twitter:image" content="' . esc_url( $img ) . '">' . "\n";
		echo '<meta name="geo.region" content="PK">' . "\n";
		echo '<meta name="geo.placename" content="' . esc_attr( clinix_opt( 'place' ) ) . '">' . "\n";
		echo '<meta name="author" content="Clinix AI">' . "\n";
		echo '<link rel="alternate" type="text/plain" href="' . esc_url( home_url( '/llms.txt' ) ) . '" title="LLMs">' . "\n";
		echo '<script type="application/ld+json">' . wp_json_encode( clinix_schema_graph(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n"; // phpcs:ignore
	},
	3
);

function clinix_schema_graph() {
	$home   = home_url( '/' );
	$org_id = $home . '#organization';
	$logo   = has_site_icon() ? get_site_icon_url( 512 ) : get_theme_file_uri( 'assets/images/icon-512.png' );
	$same   = array_values( array_filter( array( clinix_opt( 'linkedin' ), clinix_opt( 'facebook' ), clinix_opt( 'instagram' ) ) ) );
	$org    = array(
		'@type'        => array( 'Organization', 'MedicalBusiness' ),
		'@id'          => $org_id,
		'name'         => 'Clinix AI',
		'url'          => $home,
		'logo'         => array( '@type' => 'ImageObject', 'url' => $logo, 'width' => 512, 'height' => 512 ),
		'image'        => get_theme_file_uri( 'assets/images/og-image.jpg' ),
		'description'  => 'AI telehealth, remote patient monitoring and digital intake platform connected to your EHR.',
		'telephone'    => clinix_opt( 'phone_tel' ),
		'email'        => clinix_opt( 'email' ),
		'address'      => array( '@type' => 'PostalAddress', 'streetAddress' => clinix_opt( 'address' ), 'addressCountry' => 'PK' ),
		'areaServed'   => array( '@type' => 'Country', 'name' => 'Pakistan' ),
		'contactPoint' => array( '@type' => 'ContactPoint', 'telephone' => clinix_opt( 'phone_tel' ), 'contactType' => 'customer support', 'availableLanguage' => array( 'English', 'Urdu' ) ),
	);
	if ( $same ) {
		$org['sameAs'] = $same;
	}
	$graph = array( $org );
	$graph[] = array(
		'@type'           => 'WebSite',
		'@id'             => $home . '#website',
		'url'             => $home,
		'name'            => 'Clinix AI',
		'inLanguage'      => 'en',
		'publisher'       => array( '@id' => $org_id ),
		'potentialAction' => array( '@type' => 'SearchAction', 'target' => $home . '?s={search_term_string}', 'query-input' => 'required name=search_term_string' ),
	);
	$crumbs = clinix_crumbs();
	$url    = $home;
	if ( is_singular() ) {
		$url = get_permalink( get_queried_object_id() );
	} elseif ( is_home() ) {
		$url = clinix_url( 'articles' );
	}
	if ( count( $crumbs ) > 1 ) {
		$items = array();
		foreach ( $crumbs as $i => $c ) {
			$items[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0], 'item' => $c[1] );
		}
		$graph[] = array( '@type' => 'BreadcrumbList', '@id' => $url . '#breadcrumb', 'itemListElement' => $items );
	}
	$pages = clinix_pages();
	$key   = is_page() ? clinix_key_from_slug( get_post_field( 'post_name', get_queried_object_id() ) ) : ( is_front_page() ? 'home' : '' );
	if ( is_singular( 'post' ) ) {
		$cats    = get_the_category();
		$graph[] = array(
			'@type'            => 'BlogPosting',
			'@id'              => $url . '#article',
			'mainEntityOfPage' => $url,
			'headline'         => get_the_title(),
			'description'      => clinix_current_desc(),
			'image'            => clinix_post_image_url( get_the_ID() ),
			'datePublished'    => get_the_date( 'c' ),
			'dateModified'     => get_the_modified_date( 'c' ),
			'wordCount'        => str_word_count( wp_strip_all_tags( get_the_content() ) ),
			'articleSection'   => $cats ? $cats[0]->name : 'Healthcare technology',
			'inLanguage'       => 'en',
			'author'           => array( '@type' => 'Person', 'name' => get_the_author_meta( 'display_name' ) ),
			'publisher'        => array( '@id' => $org_id ),
		);
	} elseif ( $key ) {
		$type = $pages[ $key ]['schema'];
		$graph[] = array(
			'@type'       => $type,
			'@id'         => $url . '#webpage',
			'url'         => $url,
			'name'        => $pages[ $key ]['seo'],
			'description' => $pages[ $key ]['lead'],
			'isPartOf'    => array( '@id' => $home . '#website' ),
			'about'       => array( '@id' => $org_id ),
			'inLanguage'  => 'en',
		);
		if ( ! empty( $pages[ $key ]['service'] ) ) {
			$graph[] = array(
				'@type'       => 'Service',
				'@id'         => $url . '#service',
				'name'        => $pages[ $key ]['title'],
				'serviceType' => $pages[ $key ]['service'],
				'description' => $pages[ $key ]['lead'],
				'url'         => $url,
				'provider'    => array( '@id' => $org_id ),
				'areaServed'  => array( '@type' => 'Country', 'name' => 'Pakistan' ),
			);
		}
	} elseif ( is_home() ) {
		$graph[] = array( '@type' => 'CollectionPage', '@id' => $url . '#webpage', 'url' => $url, 'name' => 'Clinix AI Articles', 'isPartOf' => array( '@id' => $home . '#website' ) );
	}
	return array( '@context' => 'https://schema.org', '@graph' => $graph );
}

/* llms.txt for AI answer engines (GEO) */
add_action(
	'template_redirect',
	function () {
		if ( ! get_query_var( 'clinix_llms' ) ) {
			return;
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		$o  = "# Clinix AI\n\n> Clinix AI is a HealthTech platform offering AI telehealth, remote patient monitoring and digital intake forms, connected to electronic health records (EHR) via HL7 and FHIR. Based in " . clinix_opt( 'place' ) . ".\n\n## Key pages\n";
		foreach ( clinix_pages() as $key => $p ) {
			$o .= '- [' . $p['title'] . '](' . clinix_url( $key ) . '): ' . $p['lead'] . "\n";
		}
		$o    .= "\n## Articles\n";
		$posts = get_posts( array( 'numberposts' => 50, 'post_status' => 'publish' ) );
		foreach ( $posts as $p ) {
			$o .= '- [' . get_the_title( $p ) . '](' . get_permalink( $p ) . '): ' . wp_strip_all_tags( get_the_excerpt( $p ) ) . "\n";
		}
		$o .= "\n## Contact\n- Phone: " . clinix_opt( 'phone_display' ) . "\n- WhatsApp: " . clinix_wa_url() . "\n- Email: " . clinix_opt( 'email' ) . "\n- Hours: " . clinix_opt( 'hours' ) . "\n- Sitemap: " . home_url( '/wp-sitemap.xml' ) . "\n";
		echo $o; // phpcs:ignore
		exit;
	}
);

/* ==================================================================
 * 9. Template helpers
 * ================================================================*/
function clinix_icon( $name, $size = 24 ) {
	$p = array(
		'shield'    => '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/>',
		'activity'  => '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
		'video'     => '<rect x="2" y="6" width="14" height="12" rx="2"/><path d="M16 10l6-3v10l-6-3z"/>',
		'clipboard' => '<rect x="6" y="4" width="12" height="17" rx="2"/><path d="M9 4h6v3H9zM9 12h6M9 16h4"/>',
		'link'      => '<path d="M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1"/>',
		'chart'     => '<path d="M4 20V4M4 20h16"/><path d="M8 16v-4M12 16V8M16 16v-6"/>',
		'heart'     => '<path d="M12 21s-8-5.5-8-11a4.5 4.5 0 018-2.8A4.5 4.5 0 0120 10c0 5.5-8 11-8 11z"/>',
		'lock'      => '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
		'brain'     => '<path d="M9 4a3 3 0 00-3 3 3 3 0 00-2 5 3 3 0 002 5 3 3 0 006 1V5a3 3 0 00-3-1z"/><path d="M15 4a3 3 0 013 3 3 3 0 012 5 3 3 0 01-2 5 3 3 0 01-6 1"/>',
		'phone'     => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z"/>',
		'whatsapp'  => '<path d="M3 21l1.6-4.6A8.5 8.5 0 1112 20.5a8.4 8.4 0 01-4-1L3 21z"/><path d="M9 9.5c0 3 2.5 5.5 5.5 5.5l1-1.5-2-1-1 .8a4 4 0 01-2-2l.8-1-1-2L9 9.5z"/>',
		'pin'       => '<path d="M12 21s7-6 7-11a7 7 0 10-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
		'check'     => '<path d="M5 12l5 5 9-10"/>',
		'arrow'     => '<path d="M5 12h14M13 6l6 6-6 6"/>',
		'arrow-left'=> '<path d="M19 12H5M11 6l-6 6 6 6"/>',
		'message'   => '<path d="M4 5h16v11H9l-5 4V5z"/>',
		'spark'     => '<path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>',
		'users'     => '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-4 3-6 7-6s7 2 7 6"/><path d="M16 4.5a3.5 3.5 0 010 7M18 14c2.5.7 4 2.5 4 6"/>',
		'clock'     => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
		'mail'      => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
		'eye'       => '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
		'scale'     => '<path d="M12 3v18M5 21h14M5 7h14M5 7l-3 7a3 3 0 006 0L5 7zM19 7l-3 7a3 3 0 006 0l-3-7z"/>',
		'bolt'      => '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
		'close'     => '<path d="M6 6l12 12M18 6L6 18"/>',
		'send'      => '<path d="M3 11l18-8-8 18-2-7-8-3z"/>',
		'star'      => '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
		'book'      => '<path d="M4 5a2 2 0 012-2h13v17H6a2 2 0 00-2 2V5z"/><path d="M8 7h7"/>',
		'share'     => '<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 11l7.6-4M8.2 13l7.6 4"/>',
	);
	if ( ! isset( $p[ $name ] ) ) {
		return;
	}
	printf(
		'<svg class="icon" width="%1$d" height="%1$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%2$s</svg>',
		(int) $size,
		$p[ $name ] // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	);
}

function clinix_img( $file, $alt, $class = '', $eager = false ) {
	$path = get_theme_file_path( 'assets/images/' . $file );
	$wh   = '';
	$sz   = file_exists( $path ) ? getimagesize( $path ) : false;
	if ( $sz ) {
		$wh = ' width="' . (int) $sz[0] . '" height="' . (int) $sz[1] . '"';
	}
	printf(
		'<img src="%s" alt="%s" class="%s"%s loading="%s" decoding="async"%s>',
		esc_url( get_theme_file_uri( 'assets/images/' . $file ) ),
		esc_attr( $alt ),
		esc_attr( $class ),
		$wh, // phpcs:ignore
		$eager ? 'eager' : 'lazy',
		$eager ? ' fetchpriority="high"' : ''
	);
}

function clinix_head( $title, $lead = '', $center = false, $tag = 'h2' ) {
	echo '<div class="section-head reveal' . ( $center ? ' section-head--center' : '' ) . '">';
	echo '<' . $tag . '>' . esc_html( $title ) . '</' . $tag . '>'; // phpcs:ignore
	if ( $lead ) {
		echo '<p class="lead">' . esc_html( $lead ) . '</p>';
	}
	echo '</div>';
}

function clinix_page_hero( $key ) {
	$pages = clinix_pages();
	$p     = $pages[ $key ];
	?>
<section class="hero hero--page" aria-labelledby="page-title">
	<div class="container<?php echo $p['img'] ? ' hero__grid' : ''; ?>">
		<div>
			<nav aria-label="Breadcrumb">
				<ol class="breadcrumb">
					<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
					<?php if ( $p['parent'] ) : ?>
						<li><a href="<?php echo esc_url( clinix_url( $p['parent'] ) ); ?>"><?php echo esc_html( $pages[ $p['parent'] ]['title'] ); ?></a></li>
					<?php endif; ?>
					<li aria-current="page"><?php echo esc_html( $p['title'] ); ?></li>
				</ol>
			</nav>
			<h1 id="page-title" class="rw"><?php echo esc_html( $p['h1'] ? $p['h1'] : $p['title'] ); ?></h1>
			<p class="lead fade-up d2"><?php echo esc_html( $p['lead'] ); ?></p>
			<div class="btn-row hero__actions fade-up d3">
				<a class="btn btn--mint" href="<?php echo esc_url( clinix_url( 'contact' ) ); ?>#contact-form">Book a free demo</a>
				<a class="btn btn--glass" href="<?php echo esc_url( clinix_tel_url() ); ?>"><?php clinix_icon( 'phone', 18 ); ?> Call <?php echo esc_html( clinix_opt( 'phone_display' ) ); ?></a>
			</div>
		</div>
		<?php if ( $p['img'] ) : ?>
			<div class="hero__visual fade-up d2">
				<figure class="hero__frame glass">
					<?php clinix_img( $p['img'], $p['title'] . ' at Clinix AI', '', true ); ?>
					<figcaption><strong><?php echo esc_html( $p['title'] ); ?></strong><span><?php echo esc_html( wp_trim_words( $p['lead'], 11, '' ) ); ?></span></figcaption>
				</figure>
			</div>
		<?php endif; ?>
	</div>
</section>
	<?php
}

function clinix_faq( $items, $title = 'Frequently asked questions' ) {
	echo '<section class="section section--canvas" aria-labelledby="faq-title"><div class="container container--narrow">';
	echo '<div class="section-head reveal"><h2 id="faq-title">' . esc_html( $title ) . '</h2></div><div class="faq reveal">';
	$ld = array();
	foreach ( $items as $qa ) {
		echo '<details><summary>' . esc_html( $qa[0] ) . '</summary><p>' . esc_html( $qa[1] ) . '</p></details>';
		$ld[] = array( '@type' => 'Question', 'name' => $qa[0], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $qa[1] ) );
	}
	echo '</div></div></section>';
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $ld ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>'; // phpcs:ignore
}

function clinix_cta( $title = 'Ready to see Clinix AI in your clinic?', $text = 'Book a free walkthrough. We will map your workflow, show a live demo and give a clear plan.' ) {
	?>
<section class="section" aria-label="Get started">
	<div class="container">
		<div class="cta reveal">
			<div>
				<h2><?php echo esc_html( $title ); ?></h2>
				<p><?php echo esc_html( $text ); ?></p>
			</div>
			<div class="btn-row">
				<a class="btn btn--mint" href="<?php echo esc_url( clinix_url( 'contact' ) ); ?>#contact-form">Book a free demo</a>
				<a class="btn btn--wa" href="<?php echo esc_url( clinix_wa_url( 'Hello Clinix AI, I would like a demo.' ) ); ?>" target="_blank" rel="noopener"><?php clinix_icon( 'whatsapp', 18 ); ?> WhatsApp</a>
			</div>
		</div>
	</div>
</section>
	<?php
}

/* Article helpers: heading ids + table of contents */
function clinix_toc_content( $html ) {
	$toc  = array();
	$used = array();
	$html = preg_replace_callback(
		'/<h([23])([^>]*)>(.*?)<\/h\1>/is',
		function ( $m ) use ( &$toc, &$used ) {
			$text = trim( wp_strip_all_tags( $m[3] ) );
			if ( preg_match( '/\sid=["\']([^"\']+)["\']/', $m[2], $im ) ) {
				$id = $im[1];
			} else {
				$base = sanitize_title( $text );
				$id   = $base ? $base : 'section';
				$n    = 2;
				while ( isset( $used[ $id ] ) ) {
					$id = $base . '-' . $n++;
				}
				$m[2] .= ' id="' . esc_attr( $id ) . '"';
			}
			$used[ $id ] = 1;
			if ( '2' === $m[1] ) {
				$toc[] = array( $id, $text );
			}
			return '<h' . $m[1] . $m[2] . '>' . $m[3] . '</h' . $m[1] . '>';
		},
		$html
	);
	return array( $html, $toc );
}

function clinix_article_card( $feature = false ) {
	$cats = get_the_category();
	?>
<article <?php post_class( 'card card--media post-card reveal' . ( $feature ? ' post-feature' : '' ) ); ?>>
	<a class="card__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<img src="<?php echo esc_url( clinix_post_image_url( get_the_ID() ) ); ?>" alt="" loading="lazy" decoding="async">
	</a>
	<div class="card__body">
		<div class="meta"><?php echo $cats ? esc_html( $cats[0]->name ) . ' &middot; ' : ''; ?><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time> &middot; <?php echo (int) clinix_reading_time(); ?> min read</div>
		<<?php echo $feature ? 'h2' : 'h3'; ?>><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></<?php echo $feature ? 'h2' : 'h3'; ?>>
		<p><?php echo esc_html( wp_trim_words( has_excerpt() ? get_the_excerpt() : wp_strip_all_tags( get_the_content() ), $feature ? 38 : 24 ) ); ?></p>
		<a class="link-arrow" href="<?php the_permalink(); ?>">Read article <?php clinix_icon( 'arrow', 16 ); ?></a>
	</div>
</article>
	<?php
}

function clinix_media( $file, $alt, $title, $text, $class = '' ) {
	echo '<figure class="media reveal ' . esc_attr( $class ) . '">';
	clinix_img( $file, $alt );
	echo '<figcaption><strong>' . esc_html( $title ) . '</strong><span>' . esc_html( $text ) . '</span></figcaption></figure>';
}
