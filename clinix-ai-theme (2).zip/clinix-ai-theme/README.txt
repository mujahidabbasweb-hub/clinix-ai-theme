CLINIX AI THEME v2 - INSTALL / UPGRADE
1. WordPress Admin > Appearance > Themes > Add New > Upload Theme > clinix-ai-theme.zip > Install (choose "Replace current with uploaded" if upgrading) > Activate.
2. First admin page load runs auto-setup:
   - Creates pages: Home, About Us, Services (with child pages AI Telehealth Care, Remote Patient Monitoring, Digital Intake Forms), Features, Contact Us, Articles.
   - Sets Home as front page, Articles as posts page, builds the primary menu.
   - Sets permalinks to /%postname%/ (category base: /topics/). Old v1 URLs (/telehealth/, /rpm/, /intake/) redirect 301 to the new ones.
   - Adds 5 sample articles and 3 sample testimonials. Edit or delete them (Posts / Testimonials) before going live.
3. Appearance > Customize > Site Identity: upload your Site Icon (favicon) and logo. A default icon is built in.
4. Appearance > Customize > Clinix AI Contact: office address, map text, email, hours, city/country, social links.
5. SEO built in: unique titles/descriptions, canonical, Open Graph, Twitter cards, JSON-LD (Organization, WebSite, Breadcrumbs, Service, BlogPosting, FAQ), geo meta, XML sitemap at /wp-sitemap.xml, AI-readable /llms.txt. After launch submit /wp-sitemap.xml in Google Search Console. Set Settings > Reading > "Discourage search engines" OFF.
6. Form submissions: Admin > Inquiries and emailed to Settings > General admin email. Configure SMTP on your host for reliable delivery.
7. Add a Privacy Policy page (Settings > Privacy). The intake form is a demo; do not store real medical data without encryption and legal review.
8. AI agent re-indexes automatically when pages, posts or contact settings change.
