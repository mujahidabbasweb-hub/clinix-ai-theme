<?php
/**
 * Site header.
 *
 * @package clinix-ai
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#030B1A">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to main content</a>
<div class="scroll-progress" aria-hidden="true"></div>
<div class="aurora" aria-hidden="true"><i></i><i></i><i></i></div>
<div class="dotgrid" aria-hidden="true"></div>
<canvas id="bg-cells" aria-hidden="true"></canvas>
<div class="grain" aria-hidden="true"></div>
<div class="cursor-glow" aria-hidden="true"></div>
<div class="cursor-ring" aria-hidden="true"></div>

<header class="site-header" id="top">
	<div class="container header__inner">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Clinix AI, home">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<svg viewBox="0 0 64 64" aria-hidden="true" focusable="false"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0EA5E9"/><stop offset="1" stop-color="#075985"/></linearGradient></defs><rect width="64" height="64" rx="18" fill="url(#lg)"/><path d="M10 34h10l5-13 8 26 5-13h16" fill="none" stroke="#00FFC2" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>
				<span>Clinix<b> AI</b></span>
			<?php endif; ?>
		</a>

		<nav id="site-nav" class="site-nav" aria-label="Primary">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'menu',
					'fallback_cb'    => 'clinix_fallback_menu',
					'depth'          => 2,
				)
			);
			?>
		</nav>

		<div class="header__cta">
			<a class="btn btn--mint btn--sm" href="<?php echo esc_url( clinix_url( 'contact' ) ); ?>#contact-form">Book a demo</a>
		</div>

		<button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-nav">
			<span class="sr-only">Toggle menu</span>
			<span aria-hidden="true"></span><span aria-hidden="true"></span><span aria-hidden="true"></span>
		</button>
	</div>
</header>

<main id="main" tabindex="-1">
