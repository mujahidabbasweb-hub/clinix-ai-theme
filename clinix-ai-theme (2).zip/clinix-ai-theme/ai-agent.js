/**
 * Clinix AI Agent: lightweight client-side retrieval agent.
 * No API key, no network calls. Searches the localized site index
 * (window.ClinixAgent.index, injected by wp_localize_script).
 */
(function () {
  'use strict';

  var C = window.ClinixAgent;
  if (!C || !Array.isArray(C.index)) return;
  var doc = document;

  /* ---------------- NLP helpers ---------------- */
  var STOP = {};
  ('a an the is are was were be been am i you we they he she it to of in on at for from by with and or but if then so do does did can could would should will shall my your our me us what which who whom how when where why this that these those there here about as into than too very just please tell know want need get any some more also have has had not no yes much many long give show say let lets like ok okay hi hello hey thanks thank clinix').split(' ').forEach(function (w) { STOP[w] = 1; });

  function stem(w) {
    if (w.length > 4 && /ies$/.test(w)) return w.slice(0, -3) + 'y';
    if (w.length > 5 && /ing$/.test(w)) return w.slice(0, -3);
    if (w.length > 4 && /ed$/.test(w)) return w.slice(0, -2);
    if (w.length > 3 && /s$/.test(w) && !/ss$/.test(w)) return w.slice(0, -1);
    return w;
  }

  var GROUPS = [
    ['price', 'pricing', 'cost', 'fee', 'charge', 'quote', 'package', 'afford', 'cheap', 'expensive', 'payment'],
    ['phone', 'call', 'number', 'telephone', 'contact', 'reach', 'dial'],
    ['whatsapp', 'whatsapp'],
    ['email', 'mail'],
    ['location', 'address', 'office', 'map', 'visit', 'headquarter', 'based'],
    ['hour', 'open', 'schedule', 'availability', 'available'],
    ['telehealth', 'telemedicine', 'virtual', 'video', 'consult', 'consultation', 'online'],
    ['monitor', 'rpm', 'vital', 'wearable', 'track', 'device', 'sensor'],
    ['intake', 'form', 'register', 'registration', 'onboard', 'paperwork', 'checkin'],
    ['secure', 'security', 'privacy', 'encrypt', 'encryption', 'hipaa', 'compliance', 'safe', 'protect', 'confidential'],
    ['ehr', 'emr', 'integration', 'integrate', 'sync', 'record', 'hl7', 'fhir', 'chart'],
    ['analytic', 'analytics', 'dashboard', 'report', 'insight', 'metric'],
    ['ethic', 'ethics', 'bias', 'fair', 'responsible', 'trust'],
    ['demo', 'book', 'appointment', 'trial', 'start', 'begin', 'walkthrough'],
    ['ai', 'artificial', 'intelligence', 'agent', 'assistant', 'bot']
  ];
  var SYN = {};
  GROUPS.forEach(function (g) {
    var canon = stem(g[0]);
    g.forEach(function (w) { SYN[w] = canon; SYN[stem(w)] = canon; });
  });

  function tokens(s) {
    var out = [];
    String(s).toLowerCase().replace(/[^a-z0-9\u0600-\u06ff\s]/g, ' ').split(/\s+/).forEach(function (w) {
      if (!w || STOP[w]) return;
      var st = stem(w);
      out.push(SYN[w] || SYN[st] || st);
    });
    return out;
  }
  function uniq(a) { return a.filter(function (v, i) { return a.indexOf(v) === i; }); }

  /* ---------------- Index ---------------- */
  var docs = C.index.map(function (c) {
    var tf = {};
    function add(arr, wt) { arr.forEach(function (w) { tf[w] = (tf[w] || 0) + wt; }); }
    add(tokens(c.x), 1);
    add(tokens(c.h), 3);
    add(tokens(c.t), 0.7);
    return { c: c, tf: tf, lc: (c.h + ' ' + c.x).toLowerCase() };
  });
  var df = {};
  docs.forEach(function (d) { Object.keys(d.tf).forEach(function (w) { df[w] = (df[w] || 0) + 1; }); });
  var N = docs.length || 1;
  function idf(w) { var n = df[w] || 0; return Math.log(1 + (N - n + 0.5) / (n + 0.5)); }

  function search(q) {
    var qt = uniq(tokens(q));
    if (!qt.length) return null;
    var phrase = q.toLowerCase().trim();
    var res = [];
    docs.forEach(function (d) {
      var s = 0, m = 0;
      qt.forEach(function (w) {
        var f = d.tf[w];
        if (f) { m++; s += idf(w) * (f * 2.2) / (f + 1.2); }
      });
      if (!m) return;
      if (phrase.length > 6 && d.lc.indexOf(phrase) > -1) s += 2;
      res.push({ d: d, s: s, m: m });
    });
    if (!res.length) return null;
    res.sort(function (a, b) { return b.s - a.s; });
    var top = res[0];
    var need = qt.length <= 2 ? 1 : 0.4;
    if (top.m / qt.length < need || top.s < 1) return null;
    return { qt: qt, res: res };
  }

  function sentences(t) {
    return t.match(/[^.!?]+[.!?]+(\s|$)|[^.!?]+$/g) || [t];
  }
  function pick(text, qt) {
    if (text.length <= 300) return text;
    var ss = sentences(text).map(function (s, i) {
      var tk = tokens(s), sc = 0;
      qt.forEach(function (w) { if (tk.indexOf(w) > -1) sc++; });
      return { s: s.trim(), i: i, sc: sc };
    });
    var best = ss.slice().sort(function (a, b) { return b.sc - a.sc || a.i - b.i; }).slice(0, 2);
    best.sort(function (a, b) { return a.i - b.i; });
    var out = best.map(function (b) { return b.s; }).join(' ');
    return out.length > 380 ? out.slice(0, 377).replace(/\s+\S*$/, '') + '...' : out;
  }

  /* ---------------- UI ---------------- */
  function el(tag, attrs, kids) {
    var n = doc.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      if (k === 'text') n.textContent = attrs[k];
      else if (k === 'html') n.innerHTML = attrs[k];
      else n.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  var ICON_AI = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/></svg>';
  var ICON_X = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  var ICON_SEND = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11l18-8-8 18-2-7-8-3z"/></svg>';

  var fab = el('button', { type: 'button', 'class': 'cx-fab', 'aria-expanded': 'false', 'aria-controls': 'cx-panel', html: '<span class="cx-dot">' + ICON_AI + '</span><span class="cx-label">Ask Clinix AI</span>' });
  var hint = el('div', { 'class': 'cx-hint glass', hidden: 'hidden', text: 'Questions about our services? Ask me. I answer from this website.' });
  var log = el('div', { 'class': 'cx-log', role: 'log', 'aria-live': 'polite', 'aria-label': 'Conversation' });
  var closeBtn = el('button', { type: 'button', 'class': 'cx-close', 'aria-label': 'Close chat', html: ICON_X });
  var head = el('div', { 'class': 'cx-head' }, [
    el('span', { 'class': 'cx-dot', html: ICON_AI }),
    el('div', null, [el('h2', { id: 'cx-title', text: 'Clinix AI Agent' }), el('p', { text: 'Answers come from this website only' })]),
    closeBtn
  ]);
  var chips = el('div', { 'class': 'cx-chips', role: 'group', 'aria-label': 'Suggested questions' });
  var input = el('input', { type: 'text', id: 'cx-input', placeholder: 'Type your question...', autocomplete: 'off', maxlength: '300', 'aria-label': 'Your question' });
  var send = el('button', { type: 'submit', 'aria-label': 'Send question', html: ICON_SEND });
  var form = el('form', { 'class': 'cx-form' }, [input, send]);
  var panel = el('section', { 'class': 'cx-panel', id: 'cx-panel', role: 'dialog', 'aria-labelledby': 'cx-title', 'aria-modal': 'false' }, [head, log, chips, form]);

  (C.suggestions || []).forEach(function (s) {
    var b = el('button', { type: 'button', text: s });
    b.addEventListener('click', function () { ask(s); });
    chips.appendChild(b);
  });

  doc.body.appendChild(hint);
  doc.body.appendChild(panel);
  doc.body.appendChild(fab);

  var welcomed = false;
  function bubble(kind) {
    var m = el('div', { 'class': 'cx-msg cx-msg--' + kind });
    log.appendChild(m);
    log.scrollTop = log.scrollHeight;
    return m;
  }
  function say(text) { bubble('user').textContent = text; }

  function open() {
    panel.classList.add('is-open');
    fab.setAttribute('aria-expanded', 'true');
    hint.hidden = true;
    if (!welcomed) {
      welcomed = true;
      bubble('bot').textContent = 'Hi, I am the Clinix AI agent. Ask me about telehealth, remote monitoring, digital intake, security or how to reach our team.';
    }
    setTimeout(function () { input.focus(); }, 60);
  }
  function close() {
    panel.classList.remove('is-open');
    fab.setAttribute('aria-expanded', 'false');
    fab.focus();
  }
  fab.addEventListener('click', function () { panel.classList.contains('is-open') ? close() : open(); });
  closeBtn.addEventListener('click', close);
  doc.addEventListener('keydown', function (e) { if (e.key === 'Escape' && panel.classList.contains('is-open')) close(); });
  doc.addEventListener('clinix:open-agent', open);

  setTimeout(function () {
    var seen = false;
    try { seen = sessionStorage.getItem('cxHint'); sessionStorage.setItem('cxHint', '1'); } catch (e) {}
    if (!seen && !panel.classList.contains('is-open')) {
      hint.hidden = false;
      setTimeout(function () { hint.hidden = true; }, 7000);
    }
  }, 5000);

  /* ---------------- Answering ---------------- */
  function link(href, text, cls, ext) {
    var a = el('a', { href: href, text: text });
    if (cls) a.className = cls;
    if (ext) { a.target = '_blank'; a.rel = 'noopener'; }
    return a;
  }

  function answer(q, node) {
    node.textContent = '';
    var plain = q.toLowerCase().trim();

    if (/^(hi|hello|hey|salam|assalam|good (morning|afternoon|evening))\b[\s!.,]*$/.test(plain)) {
      node.textContent = 'Hello! How can I help you today? You can ask about our services, features, security or contact details.';
      return;
    }
    if (/^(thanks|thank you|shukria|ok thanks|great|cool)[\s!.]*$/.test(plain)) {
      node.textContent = 'You are welcome! Ask anything else whenever you like.';
      return;
    }

    var hit = search(q);
    if (!hit) {
      node.appendChild(el('span', { text: C.fallback }));
      var acts = el('div', { 'class': 'cx-actions' }, [
        link(C.waBase + '?text=' + encodeURIComponent('Hello Clinix AI admin, I have a question: ' + q), 'Ask admin on WhatsApp', '', true),
        link(C.phoneTel, 'Call ' + C.phoneText, 'alt', false)
      ]);
      node.appendChild(acts);
      return;
    }

    var top = hit.res[0];
    var used = [top];
    var second = hit.res[1];
    if (second && second.s >= top.s * 0.78 && second.d.c.h !== top.d.c.h) used.push(second);

    used.forEach(function (r, i) {
      var c = r.d.c;
      var wrap = el('div');
      if (i > 0) wrap.style.marginTop = '.8rem';
      if (c.h && c.h !== c.t) wrap.appendChild(el('strong', { text: c.h }));
      wrap.appendChild(doc.createTextNode(pick(c.x, hit.qt)));
      if (c.u) {
        var s = el('span', { 'class': 'cx-src' });
        s.appendChild(link(c.u, 'Read more on ' + c.t));
        wrap.appendChild(s);
      }
      node.appendChild(wrap);
    });
  }

  function ask(q) {
    q = (q || '').trim();
    if (!q) return;
    if (!panel.classList.contains('is-open')) open();
    say(q);
    input.value = '';
    var node = bubble('bot');
    node.innerHTML = '<span class="cx-typing" aria-label="Typing"><i></i><i></i><i></i></span>';
    setTimeout(function () {
      answer(q, node);
      log.scrollTop = log.scrollHeight;
    }, 450);
  }

  form.addEventListener('submit', function (e) { e.preventDefault(); ask(input.value); });
})();
