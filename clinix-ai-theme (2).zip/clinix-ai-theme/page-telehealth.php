<?php
/**
 * Template Name: AI Telehealth Care
 * Template Post Type: page
 *
 * @package clinix-ai
 */
get_header();
clinix_render_page( 'telehealth' );
get_footer();
