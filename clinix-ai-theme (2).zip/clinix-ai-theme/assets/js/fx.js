/**
 * Clinix AI visual effects: neural-constellation background that reacts to the
 * mouse, cursor glow/ring, card tilt, magnetic buttons, headline word reveal.
 * Respects reduced motion and pauses when the tab is hidden.
 */
(function () {
  'use strict';
  var d = document, w = window, root = d.documentElement;
  var reduce = w.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = w.matchMedia('(hover:hover) and (pointer:fine)').matches;

  var mx = -9999, my = -9999, nx = 0, ny = 0;
  var gx = w.innerWidth / 2, gy = w.innerHeight / 2, rx = gx, ry = gy;
  d.addEventListener('pointermove', function (e) {
    mx = e.clientX; my = e.clientY;
    nx = mx / w.innerWidth * 2 - 1; ny = my / w.innerHeight * 2 - 1;
    if (fine && !root.classList.contains('has-cursor')) root.classList.add('has-cursor');
  }, { passive: true });
  d.addEventListener('pointerleave', function () { mx = my = -9999; });

  /* ---------- headline word reveal ---------- */
  function splitNode(node, c) {
    if (node.nodeType === 3) {
      var frag = d.createDocumentFragment();
      node.textContent.split(/(\s+)/).forEach(function (p) {
        if (!p) return;
        if (/^\s+$/.test(p)) { frag.appendChild(d.createTextNode(' ')); return; }
        var o = d.createElement('span'), i = d.createElement('span');
        o.className = 'w'; i.className = 'wi';
        i.style.setProperty('--i', c.n++); i.textContent = p;
        o.appendChild(i); frag.appendChild(o);
      });
      node.parentNode.replaceChild(frag, node);
    } else if (node.nodeType === 1) {
      Array.prototype.slice.call(node.childNodes).forEach(function (ch) { splitNode(ch, c); });
    }
  }
  d.querySelectorAll('.rw').forEach(function (el) {
    if (!reduce) {
      var c = { n: 0 };
      Array.prototype.slice.call(el.childNodes).forEach(function (ch) { splitNode(ch, c); });
    }
    el.classList.add('is-split');
  });

  /* ---------- cursor glow + ring ---------- */
  var glow = d.querySelector('.cursor-glow'), ring = d.querySelector('.cursor-ring');
  if (fine && ring) {
    d.addEventListener('pointerover', function (e) {
      ring.classList.toggle('is-hover', !!e.target.closest('a,button,summary,input,select,textarea,[data-hover]'));
    });
  }

  /* ---------- tilt + magnetic ---------- */
  if (fine && !reduce) {
    d.querySelectorAll('.card,.bento__item,.stat,.steps li').forEach(function (el) {
      el.classList.add('tilt');
      el.addEventListener('pointermove', function (e) {
        var b = el.getBoundingClientRect();
        var px = (e.clientX - b.left) / b.width, py = (e.clientY - b.top) / b.height;
        el.style.setProperty('--ry', ((px - .5) * 7).toFixed(2) + 'deg');
        el.style.setProperty('--rx', ((.5 - py) * 7).toFixed(2) + 'deg');
        el.style.setProperty('--gx', (px * 100).toFixed(1) + '%');
        el.style.setProperty('--gy', (py * 100).toFixed(1) + '%');
      });
      el.addEventListener('pointerleave', function () {
        el.style.setProperty('--rx', '0deg'); el.style.setProperty('--ry', '0deg');
      });
    });
    d.querySelectorAll('.btn--mint,.btn--glass').forEach(function (el) {
      el.addEventListener('pointermove', function (e) {
        var b = el.getBoundingClientRect();
        var x = (e.clientX - (b.left + b.width / 2)) * .2, y = (e.clientY - (b.top + b.height / 2)) * .28;
        el.style.transform = 'translate(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px)';
      });
      el.addEventListener('pointerleave', function () { el.style.transform = ''; });
    });
  }

  /* ---------- neural constellation canvas ---------- */
  var cv = d.getElementById('bg-cells');
  var ctx = cv && cv.getContext ? cv.getContext('2d') : null;
  var W = 0, H = 0, DPR = Math.min(w.devicePixelRatio || 1, 1.5);
  var nodes = [], packets = [], links = [], LINK = 150, MLINK = 200, running = false, last = 0;

  function resize() {
    W = w.innerWidth; H = w.innerHeight;
    cv.width = W * DPR; cv.height = H * DPR;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    LINK = W < 700 ? 110 : 150;
  }
  function seed() {
    var n = W < 700 ? 34 : Math.min(84, Math.round(W * H / 17000));
    nodes = []; packets = [];
    for (var i = 0; i < n; i++) {
      nodes.push({
        x: Math.random() * W, y: Math.random() * H,
        vx: (Math.random() - .5) * .3, vy: (Math.random() - .5) * .3,
        r: .9 + Math.random() * 1.9, z: .4 + Math.random() * .6, mint: i % 9 === 0
      });
    }
  }

  function draw(t) {
    ctx.clearRect(0, 0, W, H);
    var i, j, a, b, dx, dy, dd, al;
    links.length = 0;
    for (i = 0; i < nodes.length; i++) {
      a = nodes[i];
      if (!reduce) {
        a.x += a.vx; a.y += a.vy;
        if (a.x < -20) a.x = W + 20; else if (a.x > W + 20) a.x = -20;
        if (a.y < -20) a.y = H + 20; else if (a.y > H + 20) a.y = -20;
      }
      a.px = a.x - nx * 16 * a.z; a.py = a.y - ny * 12 * a.z;
    }
    ctx.lineWidth = 1;
    for (i = 0; i < nodes.length; i++) {
      a = nodes[i];
      for (j = i + 1; j < nodes.length; j++) {
        b = nodes[j]; dx = a.px - b.px; dy = a.py - b.py; dd = dx * dx + dy * dy;
        if (dd < LINK * LINK) {
          al = (1 - Math.sqrt(dd) / LINK) * .2;
          ctx.strokeStyle = 'rgba(125,205,255,' + al.toFixed(3) + ')';
          ctx.beginPath(); ctx.moveTo(a.px, a.py); ctx.lineTo(b.px, b.py); ctx.stroke();
          if (links.length < 200) links.push([a, b]);
        }
      }
      dx = a.px - mx; dy = a.py - my; dd = Math.sqrt(dx * dx + dy * dy);
      if (dd < MLINK) {
        al = (1 - dd / MLINK) * .5;
        ctx.strokeStyle = 'rgba(0,255,194,' + al.toFixed(3) + ')';
        ctx.beginPath(); ctx.moveTo(a.px, a.py); ctx.lineTo(mx, my); ctx.stroke();
        if (!reduce) { a.x -= dx / dd * .35; a.y -= dy / dd * .35; }
      }
    }
    for (i = 0; i < nodes.length; i++) {
      a = nodes[i];
      ctx.beginPath(); ctx.arc(a.px, a.py, a.r, 0, 6.2832);
      ctx.fillStyle = a.mint ? 'rgba(0,255,194,.95)' : 'rgba(190,230,255,' + (.35 + a.z * .45).toFixed(2) + ')';
      ctx.fill();
      if (a.mint) {
        ctx.beginPath(); ctx.arc(a.px, a.py, a.r * 4.5, 0, 6.2832);
        ctx.fillStyle = 'rgba(0,255,194,.12)'; ctx.fill();
      }
    }
    if (reduce) return;
    // data packets travelling along links
    if (t - last > 900 && links.length && packets.length < 6) {
      var l = links[Math.floor(Math.random() * links.length)];
      packets.push({ a: l[0], b: l[1], p: 0 });
      last = t;
    }
    for (i = packets.length - 1; i >= 0; i--) {
      var k = packets[i]; k.p += .018;
      if (k.p >= 1) { packets.splice(i, 1); continue; }
      var x = k.a.px + (k.b.px - k.a.px) * k.p, y = k.a.py + (k.b.py - k.a.py) * k.p;
      ctx.beginPath(); ctx.arc(x, y, 2.4, 0, 6.2832); ctx.fillStyle = '#00FFC2'; ctx.fill();
      ctx.beginPath(); ctx.arc(x, y, 8, 0, 6.2832); ctx.fillStyle = 'rgba(0,255,194,.18)'; ctx.fill();
    }
  }

  function frame(t) {
    if (!running) return;
    requestAnimationFrame(frame);
    gx += (mx - gx) * .12; gy += (my - gy) * .12;
    rx += (mx - rx) * .3; ry += (my - ry) * .3;
    if (mx > -9000) {
      if (glow) glow.style.transform = 'translate3d(' + gx.toFixed(1) + 'px,' + gy.toFixed(1) + 'px,0)';
      if (ring) ring.style.transform = 'translate3d(' + rx.toFixed(1) + 'px,' + ry.toFixed(1) + 'px,0)';
    }
    if (ctx) draw(t);
  }
  function start() { if (!running) { running = true; requestAnimationFrame(frame); } }

  if (ctx) {
    resize(); seed();
    if (reduce) { draw(0); } else { start(); }
    var rt;
    w.addEventListener('resize', function () {
      clearTimeout(rt);
      rt = setTimeout(function () { resize(); seed(); if (reduce) draw(0); }, 200);
    });
    d.addEventListener('visibilitychange', function () { if (d.hidden) { running = false; } else if (!reduce) { start(); } });
  } else if (fine && !reduce) { start(); }
})();
