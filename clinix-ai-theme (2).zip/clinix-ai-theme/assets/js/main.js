(function () {
  'use strict';
  var d = document, w = window;
  var header = d.querySelector('.site-header');
  var toggle = d.querySelector('.nav-toggle');
  var nav = d.getElementById('site-nav');
  var bar = d.querySelector('.scroll-progress');

  function setMenu(open) {
    if (!toggle || !nav) return;
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    nav.classList.toggle('is-open', open);
  }
  if (toggle && nav) {
    toggle.addEventListener('click', function () { setMenu(toggle.getAttribute('aria-expanded') !== 'true'); });
    nav.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
    d.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });
    w.addEventListener('resize', function () { if (w.innerWidth > 960) setMenu(false); });
  }

  var ticking = false;
  function onScroll() {
    if (ticking) return; ticking = true;
    requestAnimationFrame(function () {
      var y = w.scrollY, h = d.documentElement.scrollHeight - w.innerHeight;
      if (header) header.classList.toggle('is-scrolled', y > 16);
      if (bar) bar.style.transform = 'scaleX(' + (h > 0 ? Math.min(y / h, 1) : 0) + ')';
      ticking = false;
    });
  }
  onScroll();
  w.addEventListener('scroll', onScroll, { passive: true });

  /* reveal */
  var items = d.querySelectorAll('.reveal');
  if ('IntersectionObserver' in w) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); } });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    items.forEach(function (el) { io.observe(el); });
  } else { items.forEach(function (el) { el.classList.add('is-in'); }); }

  /* counters */
  var cn = d.querySelectorAll('[data-count]');
  function runCount(el) {
    var to = parseFloat(el.getAttribute('data-count')), dur = 1400, t0 = null;
    if (w.matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = to; return; }
    function step(t) {
      if (!t0) t0 = t;
      var p = Math.min((t - t0) / dur, 1), e = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(to * e);
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  if ('IntersectionObserver' in w) {
    var co = new IntersectionObserver(function (es) {
      es.forEach(function (en) { if (en.isIntersecting) { runCount(en.target); co.unobserve(en.target); } });
    }, { threshold: 0.6 });
    cn.forEach(function (el) { co.observe(el); });
  } else { cn.forEach(function (el) { el.textContent = el.getAttribute('data-count'); }); }

  /* slider */
  d.querySelectorAll('[data-slider]').forEach(function (wrap) {
    var track = wrap.querySelector('.slider');
    wrap.querySelectorAll('[data-slide]').forEach(function (b) {
      b.addEventListener('click', function () {
        var dir = b.getAttribute('data-slide') === 'next' ? 1 : -1;
        track.scrollBy({ left: dir * (track.firstElementChild ? track.firstElementChild.offsetWidth + 24 : 400), behavior: 'smooth' });
      });
    });
  });

  /* TOC highlight */
  var toc = d.querySelectorAll('.toc a');
  if (toc.length && 'IntersectionObserver' in w) {
    var map = {};
    toc.forEach(function (a) { map[a.getAttribute('href').slice(1)] = a; });
    var so = new IntersectionObserver(function (es) {
      es.forEach(function (en) {
        if (en.isIntersecting) { toc.forEach(function (a) { a.classList.remove('is-active'); }); var a = map[en.target.id]; if (a) a.classList.add('is-active'); }
      });
    }, { rootMargin: '-20% 0px -70% 0px' });
    Object.keys(map).forEach(function (id) { var h = d.getElementById(id); if (h) so.observe(h); });
  }

  d.querySelectorAll('form.form').forEach(function (f) {
    f.addEventListener('submit', function () {
      var b = f.querySelector('button[type="submit"]');
      if (b) { b.disabled = true; b.textContent = 'Sending...'; }
    });
  });

  d.querySelectorAll('[data-open-agent]').forEach(function (el) {
    el.addEventListener('click', function (e) { e.preventDefault(); d.dispatchEvent(new CustomEvent('clinix:open-agent')); });
  });
})();
