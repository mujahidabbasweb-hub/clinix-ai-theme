<?php
/**
 * Site footer.
 *
 * @package clinix-ai
 */
?>
</main>

<footer class="site-footer">
	<div class="container">
		<div class="footer__grid">
			<div>
				<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<svg viewBox="0 0 64 64" aria-hidden="true" focusable="false"><rect width="64" height="64" rx="18" fill="#0284C7"/><path d="M10 34h10l5-13 8 26 5-13h16" fill="none" stroke="#00FFC2" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>
					<span>Clinix<b> AI</b></span>
				</a>
				<p style="margin-top:1rem;max-width:36ch">AI telehealth, remote patient monitoring and digital intake, connected to your EHR and built for trust.</p>
			</div>
			<div>
				<h2>Company</h2>
				<ul>
					<li><a href="<?php echo esc_url( clinix_url( 'home' ) ); ?>">Home</a></li>
					<li><a href="<?php echo esc_url( clinix_url( 'about' ) ); ?>">About Us</a></li>
					<li><a href="<?php echo esc_url( clinix_url( 'features' ) ); ?>">Features</a></li>
					<li><a href="<?php echo esc_url( clinix_url( 'articles' ) ); ?>">Articles</a></li>
					<li><a href="<?php echo esc_url( clinix_url( 'contact' ) ); ?>">Contact Us</a></li>
				</ul>
			</div>
			<div>
				<h2>Solutions</h2>
				<ul>
					<li><a href="<?php echo esc_url( clinix_url( 'services' ) ); ?>">All services</a></li>
					<li><a href="<?php echo esc_url( clinix_url( 'telehealth' ) ); ?>">AI Telehealth Care</a></li>
					<li><a href="<?php echo esc_url( clinix_url( 'rpm' ) ); ?>">Remote Patient Monitoring</a></li>
					<li><a href="<?php echo esc_url( clinix_url( 'intake' ) ); ?>">Digital Intake Forms</a></li>
				</ul>
			</div>
			<div>
				<h2>Talk to us</h2>
				<ul>
					<li><a href="<?php echo esc_url( clinix_tel_url() ); ?>"><?php echo esc_html( clinix_opt( 'phone_display' ) ); ?></a></li>
					<li><a href="<?php echo esc_url( clinix_wa_url() ); ?>" target="_blank" rel="noopener">WhatsApp chat</a></li>
					<li><a href="mailto:<?php echo esc_attr( clinix_opt( 'email' ) ); ?>"><?php echo esc_html( clinix_opt( 'email' ) ); ?></a></li>
					<li><?php echo esc_html( clinix_opt( 'hours' ) ); ?></li>
				</ul>
			</div>
		</div>
		<p class="footer__word" aria-hidden="true">Clinix AI</p>
		<div class="footer__bottom">
			<p class="disclaimer">Clinix AI is a technology platform and does not replace professional medical advice, diagnosis or treatment. In an emergency, contact your local emergency number immediately.</p>
			<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> Clinix AI. All rights reserved.</p>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
