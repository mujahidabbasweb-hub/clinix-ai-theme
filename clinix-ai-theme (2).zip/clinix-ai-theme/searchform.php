<?php
/**
 * Search form.
 *
 * @package clinix-ai
 */
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label><span class="sr-only">Search articles</span>
		<input type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="Search articles...">
	</label>
	<input type="hidden" name="post_type" value="post">
	<input type="submit" value="Search">
</form>
