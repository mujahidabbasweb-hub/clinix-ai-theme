<?php
/**
 * Single article template.
 *
 * @package clinix-ai
 */
get_header();
while ( have_posts() ) :
	the_post();
	$cats = get_the_category();
	list( $body, $toc ) = clinix_toc_content( apply_filters( 'the_content', get_the_content() ) );
	$share_url   = rawurlencode( get_permalink() );
	$share_title = rawurlencode( get_the_title() );
	?>
	<article <?php post_class(); ?>>
		<header class="hero hero--page article-hero">
			<div class="container container--narrow" style="width:min(1000px,100% - 2rem)">
				<nav aria-label="Breadcrumb">
					<ol class="breadcrumb">
						<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
						<li><a href="<?php echo esc_url( clinix_url( 'articles' ) ); ?>">Articles</a></li>
						<?php if ( $cats ) : ?>
							<li><a href="<?php echo esc_url( get_category_link( $cats[0] ) ); ?>"><?php echo esc_html( $cats[0]->name ); ?></a></li>
						<?php endif; ?>
					</ol>
				</nav>
				<h1 class="rw"><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="lead fade-up d2"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
				<div class="meta-row fade-up d3">
					<span><?php clinix_icon( 'users', 16 ); ?> <?php echo esc_html( get_the_author() ); ?></span>
					<span><?php clinix_icon( 'clock', 16 ); ?> <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time></span>
					<span><?php clinix_icon( 'book', 16 ); ?> <?php echo (int) clinix_reading_time(); ?> min read</span>
				</div>
			</div>
		</header>

		<div class="section" style="padding-top:1rem">
			<div class="container" style="width:min(1100px,100% - 2rem)">
				<figure class="article-cover reveal">
					<img src="<?php echo esc_url( clinix_post_image_url( get_the_ID() ) ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" fetchpriority="high" decoding="async">
				</figure>
				<div class="article-layout">
					<div>
						<div class="prose"><?php echo $body; // phpcs:ignore ?></div>

						<div class="share">
							<span><?php clinix_icon( 'share', 16 ); ?> Share</span>
							<a class="tag" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $share_url; // phpcs:ignore ?>" target="_blank" rel="noopener">LinkedIn</a>
							<a class="tag" href="https://twitter.com/intent/tweet?url=<?php echo $share_url; // phpcs:ignore ?>&amp;text=<?php echo $share_title; // phpcs:ignore ?>" target="_blank" rel="noopener">X</a>
							<a class="tag" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $share_url; // phpcs:ignore ?>" target="_blank" rel="noopener">Facebook</a>
							<a class="tag" href="https://wa.me/?text=<?php echo $share_title; // phpcs:ignore ?>%20<?php echo $share_url; // phpcs:ignore ?>" target="_blank" rel="noopener">WhatsApp</a>
						</div>

						<div class="author-box glass">
							<?php echo get_avatar( get_the_author_meta( 'ID' ), 64 ); ?>
							<div>
								<strong><?php echo esc_html( get_the_author() ); ?></strong>
								<p><?php echo esc_html( get_the_author_meta( 'description' ) ? get_the_author_meta( 'description' ) : 'Writes for the Clinix AI team about clinical technology and responsible medical AI.' ); ?></p>
							</div>
						</div>
					</div>

					<?php if ( $toc ) : ?>
						<aside class="toc glass" aria-label="Table of contents">
							<h2>In this article</h2>
							<ol>
								<?php foreach ( $toc as $t ) : ?>
									<li><a href="#<?php echo esc_attr( $t[0] ); ?>"><?php echo esc_html( $t[1] ); ?></a></li>
								<?php endforeach; ?>
							</ol>
						</aside>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</article>

	<?php
	$related = new WP_Query( array(
		'post_type'           => 'post',
		'posts_per_page'      => 3,
		'post__not_in'        => array( get_the_ID() ),
		'category__in'        => $cats ? wp_list_pluck( $cats, 'term_id' ) : array(),
		'ignore_sticky_posts' => true,
	) );
	if ( ! $related->have_posts() ) {
		$related = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 3, 'post__not_in' => array( get_the_ID() ), 'ignore_sticky_posts' => true ) );
	}
	if ( $related->have_posts() ) :
		?>
		<section class="section section--canvas" aria-labelledby="rel-title">
			<div class="container">
				<?php clinix_head( 'Keep reading' ); ?>
				<div class="grid grid--3 stagger">
					<?php
					while ( $related->have_posts() ) {
						$related->the_post();
						clinix_article_card( false );
					}
					wp_reset_postdata();
					?>
				</div>
			</div>
		</section>
	<?php endif; ?>
	<?php
	clinix_cta();
endwhile;
get_footer();
