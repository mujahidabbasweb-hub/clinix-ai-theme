<?php
/**
 * 404 template.
 *
 * @package clinix-ai
 */
get_header();
?>
<section class="hero hero--page">
	<div class="container">
		<h1 class="rw">We could not find that page</h1>
		<p class="lead">The link may be old or mistyped. Try the home page, read our articles, or ask the AI agent in the bottom-right corner.</p>
		<div class="btn-row hero__actions">
			<a class="btn btn--mint" href="<?php echo esc_url( home_url( '/' ) ); ?>">Go to home</a>
			<a class="btn btn--glass" href="<?php echo esc_url( clinix_url( 'articles' ) ); ?>">Read articles</a>
		</div>
	</div>
</section>
<?php
get_footer();
