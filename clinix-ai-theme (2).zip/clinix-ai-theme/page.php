<?php
/**
 * Universal template for Main Pages and Sub Pages.
 * Known Clinix pages (by slug) render their designed layout; any other
 * page gets a clean hero plus the editor content.
 *
 * @package clinix-ai
 */
get_header();

$clinix_key = clinix_key_from_slug( get_post_field( 'post_name', get_queried_object_id() ) );

if ( $clinix_key ) {
	clinix_render_page( $clinix_key );
} else {
	while ( have_posts() ) {
		the_post();
		?>
		<section class="hero hero--page">
			<div class="container">
				<h1 class="rw"><?php the_title(); ?></h1>
			</div>
		</section>
		<section class="section">
			<div class="container prose"><?php the_content(); ?></div>
		</section>
		<?php
	}
	clinix_cta();
}
get_footer();
