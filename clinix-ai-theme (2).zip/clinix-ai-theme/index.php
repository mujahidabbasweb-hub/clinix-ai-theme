<?php
/**
 * Main template: front page fallback, Articles listing, categories, search.
 *
 * @package clinix-ai
 */
get_header();

if ( is_front_page() && is_home() ) {
	clinix_render_page( 'home' );
} else {
	if ( is_search() ) {
		$h1   = 'Search results';
		$lead = 'Results for "' . get_search_query() . '".';
	} elseif ( is_category() ) {
		$h1   = single_cat_title( '', false );
		$lead = category_description() ? wp_strip_all_tags( category_description() ) : 'Articles on this topic from the Clinix AI team.';
	} elseif ( is_archive() ) {
		$h1   = get_the_archive_title();
		$lead = 'Articles from the Clinix AI team.';
	} else {
		$h1   = 'Articles on AI healthcare technology';
		$lead = 'Practical guides on telehealth, remote monitoring, digital intake, interoperability and responsible medical AI.';
	}
	?>
	<section class="hero hero--page" aria-labelledby="page-title">
		<div class="container">
			<nav aria-label="Breadcrumb">
				<ol class="breadcrumb">
					<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
					<li aria-current="page">Articles</li>
				</ol>
			</nav>
			<h1 id="page-title" class="rw"><?php echo esc_html( $h1 ); ?></h1>
			<p class="lead fade-up d2"><?php echo esc_html( $lead ); ?></p>
			<?php get_search_form(); ?>
		</div>
	</section>

	<section class="section">
		<div class="container">
			<?php
			$cats = get_categories( array( 'hide_empty' => true ) );
			if ( $cats ) :
				?>
				<nav class="tags" aria-label="Article topics">
					<a class="tag<?php echo ( is_home() && ! is_category() ) ? ' is-active' : ''; ?>" href="<?php echo esc_url( clinix_url( 'articles' ) ); ?>">All</a>
					<?php foreach ( $cats as $c ) : ?>
						<a class="tag<?php echo ( is_category( $c->term_id ) ) ? ' is-active' : ''; ?>" href="<?php echo esc_url( get_category_link( $c ) ); ?>"><?php echo esc_html( $c->name ); ?></a>
					<?php endforeach; ?>
				</nav>
			<?php endif; ?>

			<?php if ( have_posts() ) : ?>
				<?php
				$first = true;
				$open  = false;
				while ( have_posts() ) :
					the_post();
					if ( $first && ! is_paged() && ! is_search() ) {
						clinix_article_card( true );
						$first = false;
						continue;
					}
					if ( ! $open ) {
						echo '<div class="grid grid--3 stagger">';
						$open = true;
					}
					$first = false;
					clinix_article_card( false );
				endwhile;
				if ( $open ) {
					echo '</div>';
				}
				?>
				<div class="pagination"><?php the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => 'Previous', 'next_text' => 'Next' ) ); ?></div>
			<?php else : ?>
				<p class="lead">Nothing found here yet. Try another topic or ask our AI agent.</p>
			<?php endif; ?>
		</div>
	</section>
	<?php
	clinix_cta();
}
get_footer();
