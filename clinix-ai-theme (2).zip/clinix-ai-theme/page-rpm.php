<?php
/**
 * Template Name: Remote Patient Monitoring
 * Template Post Type: page
 *
 * @package clinix-ai
 */
get_header();
clinix_render_page( 'rpm' );
get_footer();
