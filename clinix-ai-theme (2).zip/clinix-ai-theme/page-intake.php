<?php
/**
 * Template Name: Digital Intake Forms
 * Template Post Type: page
 *
 * @package clinix-ai
 */
get_header();
clinix_render_page( 'intake' );
get_footer();
