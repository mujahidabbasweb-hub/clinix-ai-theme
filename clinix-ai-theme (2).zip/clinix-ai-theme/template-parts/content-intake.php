<?php
/**
 * Digital Intake Forms sub page.
 *
 * @package clinix-ai
 */
?>
<section class="section" aria-labelledby="in-what">
	<div class="container split">
		<?php clinix_media( 'care-team.jpg', 'Doctors reviewing a patient form together on a tablet', 'Forms that flow into the chart', 'Answers reach the record with no retyping.' ); ?>
		<div class="reveal">
			<h2 id="in-what">What are digital intake forms?</h2>
			<p class="lead">Online forms that collect patient history, symptoms and consent before the visit, and send the answers straight to the chart.</p>
			<ul class="ticks">
				<li><?php clinix_icon( 'check', 20 ); ?> Adaptive questions skip what does not apply.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Works on phones, tablets and computers.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Digital consent with a time-stamped record.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Answers are written to the EHR with no retyping.</li>
			</ul>
		</div>
	</div>
</section>

<section class="section section--canvas" aria-labelledby="in-ben">
	<div class="container">
		<?php clinix_head( 'Why clinics switch from paper', '', false ); ?>
		<div class="grid grid--3">
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'clock', 24 ); ?></span><h3>Faster check-in</h3><p>Patients finish at home, so waiting rooms stay calm.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'check', 24 ); ?></span><h3>Fewer errors</h3><p>Typed answers replace handwriting that staff must decipher.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'lock', 24 ); ?></span><h3>Safer data</h3><p>Forms are encrypted and stored securely, never left on a clipboard.</p></div>
		</div>
	</div>
</section>

<section class="section" aria-labelledby="in-try">
	<div class="container split" style="align-items:start">
		<div class="reveal">
			<h2 id="in-try">Try a sample intake form</h2>
			<p class="lead">This demo shows how a short intake looks to patients. Submitted details go to our admin team only.</p>
			<p>Please do not enter real medical information in this demo. Your clinic version is configured with your own questions and storage rules.</p>
		</div>
		<div class="form-card reveal" id="intake-form">
			<?php clinix_form_notice(); ?>
			<form class="form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="clinix_form">
				<input type="hidden" name="form_type" value="intake">
				<?php wp_nonce_field( 'clinix_form', 'clinix_nonce' ); ?>
				<div class="hp" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
				<div class="form__row">
					<div class="field"><label for="i-name">Full name</label><input id="i-name" name="name" type="text" required autocomplete="name"></div>
					<div class="field"><label for="i-dob">Date of birth</label><input id="i-dob" name="dob" type="date"></div>
				</div>
				<div class="form__row">
					<div class="field"><label for="i-email">Email</label><input id="i-email" name="email" type="email" required autocomplete="email"></div>
					<div class="field"><label for="i-phone">Phone</label><input id="i-phone" name="phone" type="tel" autocomplete="tel"></div>
				</div>
				<div class="field"><label for="i-reason">Reason for visit</label>
					<select id="i-reason" name="reason">
						<option>General check-up</option><option>New symptom</option><option>Follow-up visit</option><option>Medication review</option><option>Other</option>
					</select>
				</div>
				<div class="field"><label for="i-sym">Current symptoms</label><textarea id="i-sym" name="symptoms" style="min-height:100px"></textarea></div>
				<div class="field"><label for="i-meds">Current medications</label><textarea id="i-meds" name="meds" style="min-height:80px"></textarea></div>
				<div class="field"><label for="i-all">Allergies</label><textarea id="i-all" name="allergies" style="min-height:80px"></textarea></div>
				<div class="field field--check"><input id="i-consent" name="consent" type="checkbox" value="1" required><label for="i-consent">I agree that Clinix AI may store these details to contact me about this request.</label></div>
				<button class="btn btn--blue" type="submit">Submit sample form</button>
			</form>
		</div>
	</div>
</section>
<?php
clinix_faq(
	array(
		array( 'Can patients complete digital intake forms on a phone?', 'Yes. Forms adapt to any screen size and work in the phone browser with no app.' ),
		array( 'Are digital intake forms secure?', 'Yes. Responses are encrypted in transit and at rest and are visible only to authorised staff.' ),
		array( 'Can I customise the questions in the intake form?', 'Yes. Clinix AI builds forms with your own questions, branching rules and consent wording.' ),
	)
);
clinix_cta();
