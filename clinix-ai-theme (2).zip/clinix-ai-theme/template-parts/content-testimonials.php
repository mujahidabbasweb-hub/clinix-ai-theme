<?php
/**
 * Testimonials slider (manage under Testimonials in the admin menu).
 *
 * @package clinix-ai
 */
global $clinix_indexing;
if ( ! empty( $clinix_indexing ) ) {
	return;
}
$clinix_t = get_posts( array( 'post_type' => 'clinix_testimonial', 'post_status' => 'publish', 'numberposts' => 9, 'orderby' => 'menu_order date', 'order' => 'ASC' ) );
if ( ! $clinix_t ) {
	return;
}
?>
<section class="section" aria-labelledby="testi-title" data-slider>
	<div class="container">
		<div class="section-head reveal">
			<h2 id="testi-title">What care teams say</h2>
			<p class="lead">Feedback from the clinicians and managers who use Clinix AI every day.</p>
		</div>
		<div class="slider" tabindex="0" aria-label="Testimonials">
			<?php foreach ( $clinix_t as $t ) : ?>
				<figure class="card quote">
					<div class="stars" role="img" aria-label="5 out of 5 stars"><?php for ( $i = 0; $i < 5; $i++ ) { clinix_icon( 'star', 18 ); } ?></div>
					<blockquote><?php echo esc_html( wp_strip_all_tags( $t->post_content ) ); ?></blockquote>
					<figcaption>
						<i aria-hidden="true"><?php echo esc_html( strtoupper( mb_substr( $t->post_title, 0, 1 ) ) ); ?></i>
						<span><strong><?php echo esc_html( $t->post_title ); ?></strong><?php echo esc_html( $t->post_excerpt ); ?></span>
					</figcaption>
				</figure>
			<?php endforeach; ?>
		</div>
		<div class="slider-nav">
			<button type="button" data-slide="prev" aria-label="Previous testimonial"><?php clinix_icon( 'arrow-left', 20 ); ?></button>
			<button type="button" data-slide="next" aria-label="Next testimonial"><?php clinix_icon( 'arrow', 20 ); ?></button>
		</div>
	</div>
</section>
