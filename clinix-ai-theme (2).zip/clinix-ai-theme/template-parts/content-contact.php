<?php
/**
 * Contact Us sections.
 *
 * @package clinix-ai
 */
$map_url = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( clinix_opt( 'map_query' ) );
?>
<section class="section" aria-labelledby="ways-title">
	<div class="container">
		<?php clinix_head( 'Reach us your way', 'Pick the channel that suits you. We reply during opening hours.', false ); ?>
		<div class="contact-cards">
			<div class="card reveal">
				<span class="ico"><?php clinix_icon( 'phone', 24 ); ?></span>
				<h3>Call us</h3>
				<a href="<?php echo esc_url( clinix_tel_url() ); ?>"><?php echo esc_html( clinix_opt( 'phone_display' ) ); ?></a>
				<a class="btn btn--blue btn--sm" style="margin-top:.6rem;align-self:flex-start" href="<?php echo esc_url( clinix_tel_url() ); ?>">Call now</a>
			</div>
			<div class="card reveal">
				<span class="ico"><?php clinix_icon( 'whatsapp', 24 ); ?></span>
				<h3>WhatsApp</h3>
				<p>Chat directly with our team.</p>
				<a class="btn btn--wa btn--sm" style="align-self:flex-start" href="<?php echo esc_url( clinix_wa_url( 'Hello Clinix AI, I would like to know more.' ) ); ?>" target="_blank" rel="noopener">Open WhatsApp</a>
			</div>
			<div class="card reveal">
				<span class="ico"><?php clinix_icon( 'mail', 24 ); ?></span>
				<h3>Email</h3>
				<a href="mailto:<?php echo esc_attr( clinix_opt( 'email' ) ); ?>"><?php echo esc_html( clinix_opt( 'email' ) ); ?></a>
			</div>
			<div class="card reveal">
				<span class="ico"><?php clinix_icon( 'clock', 24 ); ?></span>
				<h3>Opening hours</h3>
				<p><?php echo esc_html( clinix_opt( 'hours' ) ); ?></p>
			</div>
		</div>
	</div>
</section>

<section class="section section--canvas" aria-labelledby="form-title">
	<div class="container split" style="align-items:start">
		<div class="reveal">
			<h2 id="form-title">Send us a message</h2>
			<p class="lead">Tell us about your clinic and what you would like to improve. We will reply within one working day.</p>
			<ul class="ticks">
				<li><?php clinix_icon( 'check', 20 ); ?> Free, no-obligation walkthrough.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Do not include sensitive patient details in this form.</li>
			</ul>
		</div>
		<div class="form-card reveal" id="contact-form">
			<?php clinix_form_notice(); ?>
			<form class="form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="clinix_form">
				<input type="hidden" name="form_type" value="contact">
				<?php wp_nonce_field( 'clinix_form', 'clinix_nonce' ); ?>
				<div class="hp" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
				<div class="form__row">
					<div class="field"><label for="c-name">Full name</label><input id="c-name" name="name" type="text" required autocomplete="name"></div>
					<div class="field"><label for="c-email">Email</label><input id="c-email" name="email" type="email" required autocomplete="email"></div>
				</div>
				<div class="field"><label for="c-phone">Phone (optional)</label><input id="c-phone" name="phone" type="tel" autocomplete="tel"></div>
				<div class="field"><label for="c-msg">How can we help?</label><textarea id="c-msg" name="message" required></textarea></div>
				<button class="btn btn--blue" type="submit">Send message</button>
			</form>
		</div>
	</div>
</section>

<section class="section" aria-labelledby="map-title">
	<div class="container">
		<?php clinix_head( 'Find our office', '', false ); ?>
		<div class="map reveal">
			<svg class="map__art" viewBox="0 0 800 400" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">
				<rect width="800" height="400" fill="#0B1220"/>
				<g stroke="#1E293B" stroke-width="2" fill="none">
					<path d="M0 90h800M0 200h800M0 310h800M130 0v400M300 0v400M470 0v400M640 0v400"/>
				</g>
				<g stroke="#0284C7" stroke-width="5" fill="none" stroke-linecap="round" opacity=".7">
					<path d="M0 340C150 300 250 230 400 190S650 90 800 50"/>
					<path d="M200 400C230 300 330 250 420 120S600 20 640 0" stroke-width="3"/>
				</g>
				<g fill="#16213A"><rect x="150" y="110" width="120" height="70" rx="8"/><rect x="500" y="220" width="110" height="70" rx="8"/><rect x="330" y="240" width="110" height="50" rx="8"/><rect x="660" y="100" width="100" height="80" rx="8"/></g>
			</svg>
			<span class="map__pin" aria-hidden="true"><?php clinix_icon( 'pin', 48 ); ?></span>
			<div class="map__card glass">
				<address>
					<strong>Clinix AI</strong>
					<span><?php echo esc_html( clinix_opt( 'address' ) ); ?></span>
				</address>
				<a class="btn btn--mint btn--sm" href="<?php echo esc_url( $map_url ); ?>" target="_blank" rel="noopener"><?php clinix_icon( 'pin', 18 ); ?> Get directions</a>
			</div>
		</div>
	</div>
</section>
<?php
clinix_faq(
	array(
		array( 'What is the Clinix AI phone number?', 'You can call Clinix AI on ' . clinix_opt( 'phone_display' ) . '.' ),
		array( 'Can I contact Clinix AI on WhatsApp?', 'Yes. Use the green WhatsApp button on any page or message ' . clinix_opt( 'phone_display' ) . ' directly.' ),
		array( 'When will you reply to my message?', 'We reply within one working day. Opening hours are ' . clinix_opt( 'hours' ) . '.' ),
	)
);
