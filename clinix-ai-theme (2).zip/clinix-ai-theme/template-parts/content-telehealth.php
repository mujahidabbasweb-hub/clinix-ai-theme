<?php
/**
 * AI Telehealth Care sub page.
 *
 * @package clinix-ai
 */
?>
<section class="section" aria-labelledby="th-what">
	<div class="container split">
		<?php clinix_media( 'mri-consult.jpg', 'Doctor explaining brain scan images on a tablet to a patient', 'Visits prepared by AI', 'Charts and scans are summarised before the patient joins.' ); ?>
		<div class="reveal">
			<h2 id="th-what">What is AI telehealth care?</h2>
			<p class="lead">Video consultations where AI handles the preparation and the paperwork, so the clinician can give full attention to the patient.</p>
			<p>Before each visit, Clinix AI assembles a one-page summary of history, recent results and open issues. After the visit, it drafts the note and follow-up orders for the clinician to review and sign.</p>
		</div>
	</div>
</section>

<section class="section section--canvas" aria-labelledby="th-ben">
	<div class="container">
		<?php clinix_head( 'Benefits for patients and teams', '', false ); ?>
		<div class="grid grid--3">
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'video', 24 ); ?></span><h3>Secure video visits</h3><p>Browser-based calls with no app to install and end-to-end encryption.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'brain', 24 ); ?></span><h3>AI-prepared charts</h3><p>Relevant history and results are summarised before the patient joins.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'clipboard', 24 ); ?></span><h3>Automatic visit notes</h3><p>Draft notes and orders are ready for clinician review within minutes.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'clock', 24 ); ?></span><h3>Shorter waits</h3><p>Smart scheduling and reminders reduce missed appointments.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'link', 24 ); ?></span><h3>EHR connected</h3><p>Every visit is saved straight to the patient record.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'eye', 24 ); ?></span><h3>Accessible</h3><p>Captions, large controls and screen-reader support for all patients.</p></div>
		</div>
	</div>
</section>

<section class="section" aria-labelledby="th-how">
	<div class="container">
		<?php clinix_head( 'How a telehealth visit works', '', false ); ?>
		<ol class="steps">
			<li class="reveal"><h3>Book</h3><p>The patient chooses a time by link, text or phone.</p></li>
			<li class="reveal"><h3>Prepare</h3><p>AI builds a summary while the patient completes a short check-in.</p></li>
			<li class="reveal"><h3>Consult</h3><p>The clinician and patient meet over secure video.</p></li>
			<li class="reveal"><h3>Follow up</h3><p>Notes, prescriptions and reminders are sent after review.</p></li>
		</ol>
	</div>
</section>
<?php
clinix_faq(
	array(
		array( 'Do patients need to install an app for AI telehealth?', 'No. Patients join from a link in their phone or computer browser.' ),
		array( 'Is the video consultation private?', 'Yes. Video and chat are encrypted end to end, and no visit is recorded unless your clinic enables it with patient consent.' ),
		array( 'Does AI make clinical decisions during telehealth?', 'No. AI prepares summaries and drafts notes. The clinician reviews everything and makes every decision.' ),
	)
);
clinix_cta();
