<?php
/**
 * Latest articles strip for the home page.
 *
 * @package clinix-ai
 */
global $clinix_indexing;
if ( ! empty( $clinix_indexing ) ) {
	return;
}
$clinix_q = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 3, 'ignore_sticky_posts' => true ) );
if ( ! $clinix_q->have_posts() ) {
	return;
}
?>
<section class="section section--canvas" aria-labelledby="art-title">
	<div class="container">
		<div class="section-head reveal">
			<h2 id="art-title">Latest articles</h2>
			<p class="lead">Practical guides on clinical technology and responsible medical AI.</p>
		</div>
		<div class="grid grid--3 stagger">
			<?php
			while ( $clinix_q->have_posts() ) {
				$clinix_q->the_post();
				clinix_article_card( false );
			}
			wp_reset_postdata();
			?>
		</div>
		<p style="margin-top:2rem"><a class="btn btn--line" href="<?php echo esc_url( clinix_url( 'articles' ) ); ?>">View all articles <?php clinix_icon( 'arrow', 18 ); ?></a></p>
	</div>
</section>
