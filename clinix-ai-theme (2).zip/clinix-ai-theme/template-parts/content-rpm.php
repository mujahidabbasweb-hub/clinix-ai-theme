<?php
/**
 * Remote Patient Monitoring sub page.
 *
 * @package clinix-ai
 */
?>
<section class="section" aria-labelledby="rpm-what">
	<div class="container split">
		<div class="reveal">
			<h2 id="rpm-what">What is remote patient monitoring?</h2>
			<p class="lead">Remote patient monitoring (RPM) tracks health readings from a patient's home and alerts your team when something needs attention.</p>
			<p>Patients use simple connected devices such as blood pressure cuffs, glucose meters, pulse oximeters and scales. Readings arrive automatically in the Clinix AI dashboard, where smart thresholds flag changes early.</p>
			<ul class="ticks">
				<li><?php clinix_icon( 'check', 20 ); ?> Supports chronic conditions, post-surgery recovery and elderly care.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Works with common Bluetooth and cellular devices.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Alerts reach the right clinician by app, SMS or email.</li>
			</ul>
		</div>
		<?php clinix_media( 'robotic-therapy.jpg', 'Older clinician with a control tablet supervising a robotic arm over a patient', 'Care beyond the clinic', 'Clinicians supervise connected tools and live patient data.' ); ?>
	</div>
</section>

<section class="section section--dark" aria-labelledby="rpm-feat">
	<div class="container">
		<?php clinix_head( 'Built for 24/7 awareness', 'Your team sees what matters and ignores the noise.', false ); ?>
		<div class="grid grid--4">
			<div class="card card--dark reveal"><span class="ico"><?php clinix_icon( 'activity', 24 ); ?></span><h3>Live vitals</h3><p>Heart rate, blood pressure, oxygen, glucose and weight in one view.</p></div>
			<div class="card card--dark reveal"><span class="ico"><?php clinix_icon( 'bolt', 24 ); ?></span><h3>Smart alerts</h3><p>Personal thresholds and trend detection reduce false alarms.</p></div>
			<div class="card card--dark reveal"><span class="ico"><?php clinix_icon( 'chart', 24 ); ?></span><h3>Trend reports</h3><p>Weekly summaries show progress for patients and care teams.</p></div>
			<div class="card card--dark reveal"><span class="ico"><?php clinix_icon( 'link', 24 ); ?></span><h3>EHR sync</h3><p>Readings and alerts are saved to the patient record automatically.</p></div>
		</div>
	</div>
</section>

<section class="section" aria-labelledby="rpm-how">
	<div class="container">
		<?php clinix_head( 'How remote monitoring works', '', false ); ?>
		<ol class="steps">
			<li class="reveal"><h3>Enrol</h3><p>The clinician selects devices and thresholds for the patient.</p></li>
			<li class="reveal"><h3>Connect</h3><p>The patient pairs devices in minutes with a guided setup.</p></li>
			<li class="reveal"><h3>Monitor</h3><p>Readings stream in and AI watches for meaningful change.</p></li>
			<li class="reveal"><h3>Respond</h3><p>Your team is alerted and can call, message or book a visit.</p></li>
		</ol>
	</div>
</section>
<?php
clinix_faq(
	array(
		array( 'Which devices work with remote patient monitoring?', 'Clinix AI supports common blood pressure monitors, glucose meters, pulse oximeters, thermometers and smart scales. Contact us to confirm specific models.' ),
		array( 'What happens when a reading is abnormal?', 'The system sends an alert to the responsible clinician based on thresholds you set. Your team decides the next step.' ),
		array( 'Is RPM suitable for elderly patients?', 'Yes. Setup is guided and readings send automatically, so patients rarely need to use an app.' ),
	)
);
clinix_cta();
