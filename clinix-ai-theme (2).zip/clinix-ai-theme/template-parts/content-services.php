<?php
/**
 * Services overview.
 *
 * @package clinix-ai
 */
$services = array(
	array( 'video', 'AI Telehealth Care', 'Secure video consultations with AI-prepared charts and automatic visit summaries.', 'telehealth' ),
	array( 'activity', 'Remote Patient Monitoring', 'Connected devices, smart alerts and 24/7 dashboards for patients at home.', 'rpm' ),
	array( 'clipboard', 'Digital Intake Forms', 'Adaptive, accessible forms that replace paper and feed the record directly.', 'intake' ),
	array( 'link', 'EHR Integration', 'Two-way sync with your electronic health record using HL7 and FHIR standards.', '' ),
	array( 'chart', 'Clinical Analytics', 'Real-time dashboards that show risk, workload and outcomes across your patients.', '' ),
	array( 'shield', 'Security and Compliance Support', 'Risk assessments, access reviews and policy templates aligned to HIPAA.', '' ),
);
?>
<section class="section" aria-labelledby="all-svc">
	<div class="container">
		<?php clinix_head( 'Everything your clinic needs to deliver connected care', 'Choose one solution or combine them. Every service shares the same secure core.', false ); ?>
		<div class="grid grid--3">
			<?php foreach ( $services as $s ) : ?>
				<article class="card reveal">
					<span class="ico"><?php clinix_icon( $s[0], 24 ); ?></span>
					<h3><?php echo esc_html( $s[1] ); ?></h3>
					<p><?php echo esc_html( $s[2] ); ?></p>
					<?php if ( $s[3] ) : ?>
						<a class="link-arrow" href="<?php echo esc_url( clinix_url( $s[3] ) ); ?>">Learn more <?php clinix_icon( 'arrow', 16 ); ?></a>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="section section--dark" aria-labelledby="proc-title">
	<div class="container">
		<?php clinix_head( 'How a Clinix AI project runs', 'A clear four-step path from first call to a live, measured rollout.', false ); ?>
		<ol class="steps">
			<li class="reveal" style="background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.16)"><h3>Discover</h3><p style="color:var(--on-dark-2)">We map your workflows, systems and goals in a short workshop.</p></li>
			<li class="reveal" style="background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.16)"><h3>Integrate</h3><p style="color:var(--on-dark-2)">We connect your EHR, devices and forms in a secure test environment.</p></li>
			<li class="reveal" style="background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.16)"><h3>Launch</h3><p style="color:var(--on-dark-2)">Your team is trained and the first patients go live with our support.</p></li>
			<li class="reveal" style="background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.16)"><h3>Optimise</h3><p style="color:var(--on-dark-2)">We review analytics together and tune alerts, forms and workflows.</p></li>
		</ol>
	</div>
</section>

<section class="section" aria-labelledby="conn-title">
	<div class="container split">
		<?php clinix_media( 'robot-flower.jpg', 'Woman delighted as a robot arm offers her a red flower', 'Technology with warmth', 'Automation that feels kind, clear and human.' ); ?>
		<div class="reveal">
			<h2 id="conn-title">Technology with a human touch</h2>
			<p class="lead">Automation should feel kind. We test every patient-facing screen for clarity, warmth and accessibility.</p>
			<ul class="ticks">
				<li><?php clinix_icon( 'check', 20 ); ?> Plain language in every message and form.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Large touch targets and screen-reader support.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Always an easy route to a real person.</li>
			</ul>
		</div>
	</div>
</section>
<?php
clinix_faq(
	array(
		array( 'How much does Clinix AI cost?', 'Pricing depends on clinic size and the services you choose. Contact us for a tailored quote after a free walkthrough.' ),
		array( 'How long does implementation take?', 'Most clinics go live within a few weeks. Timing depends on EHR access and the number of services you start with.' ),
		array( 'Can I start with only one service?', 'Yes. Many clinics begin with digital intake or telehealth and add remote monitoring later.' ),
	)
);
clinix_cta();
