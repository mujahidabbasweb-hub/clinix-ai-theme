<?php
/**
 * Home page sections.
 *
 * @package clinix-ai
 */
$spikes = '';
for ( $i = 0; $i < 64; $i++ ) {
	$a   = deg2rad( $i * 360 / 64 );
	$r1  = 128;
	$r2  = ( 0 === $i % 2 ) ? 168 : 152;
	$spikes .= sprintf( '<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f"/>', 200 + cos( $a ) * $r1, 200 + sin( $a ) * $r1, 200 + cos( $a ) * $r2, 200 + sin( $a ) * $r2 );
}
?>
<section class="hero" aria-labelledby="hero-title">
	<div class="container hero__grid">
		<div>
			<p class="status-pill fade-up"><span class="pulse"></span> Live care intelligence for modern clinics</p>
			<h1 id="hero-title" class="rw">Healthcare that thinks ahead, so clinicians can focus on people.</h1>
			<p class="lead fade-up d2">Clinix AI brings AI telehealth, remote patient monitoring and digital intake into one secure platform that syncs with your EHR in real time.</p>
			<div class="btn-row hero__actions fade-up d3">
				<a class="btn btn--mint" href="<?php echo esc_url( clinix_url( 'contact' ) ); ?>#contact-form">Book a free demo</a>
				<a class="btn btn--glass" href="<?php echo esc_url( clinix_url( 'services' ) ); ?>">Explore services <?php clinix_icon( 'arrow', 18 ); ?></a>
			</div>
			<ul class="chips fade-up d4">
				<li><?php clinix_icon( 'lock', 16 ); ?> Encrypted in transit and at rest</li>
				<li><?php clinix_icon( 'shield', 16 ); ?> HIPAA-aligned workflows</li>
				<li><?php clinix_icon( 'eye', 16 ); ?> Accessible by design</li>
			</ul>
		</div>

		<div class="hero__visual fade-up d2">
			<div class="orb" aria-hidden="true">
				<svg viewBox="0 0 400 400" focusable="false">
					<defs>
						<radialGradient id="og1" cx="45%" cy="40%" r="65%"><stop offset="0" stop-color="#9FE8FF" stop-opacity=".95"/><stop offset=".45" stop-color="#1E90D6" stop-opacity=".85"/><stop offset="1" stop-color="#06335E" stop-opacity=".95"/></radialGradient>
						<radialGradient id="og2" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#021B36"/><stop offset="1" stop-color="#0B4F8A"/></radialGradient>
					</defs>
					<g class="orb__spikes" stroke="#7DD3FC" stroke-width="3" stroke-linecap="round" opacity=".75"><?php echo $spikes; // phpcs:ignore ?></g>
					<circle class="orb__core" cx="200" cy="200" r="122" fill="url(#og1)"/>
					<g class="orb__ring" fill="none" stroke="#BDF3FF" stroke-opacity=".5" stroke-width="1.5" stroke-dasharray="3 9"><circle cx="200" cy="200" r="104"/></g>
					<circle cx="200" cy="200" r="58" fill="url(#og2)" stroke="#7DD3FC" stroke-opacity=".6"/>
					<g fill="#00FFC2" opacity=".9"><circle cx="178" cy="190" r="3.5"/><circle cx="214" cy="176" r="3"/><circle cx="224" cy="214" r="4"/><circle cx="190" cy="226" r="2.5"/><circle cx="206" cy="200" r="2"/></g>
				</svg>
				<span class="orb-tag orb-tag--1"><i></i><span>Vitals synced<small>Live from 3 devices</small></span></span>
				<span class="orb-tag orb-tag--2"><i></i><span>Anomaly detected<small>Care team alerted</small></span></span>
				<span class="orb-tag orb-tag--3"><i></i><span>Intake complete<small>Added to the chart</small></span></span>
			</div>
			<figure class="hero__photo glass">
				<?php clinix_img( 'doctor-tablet.jpg', 'Smiling doctor in teal scrubs reviewing patient data on a tablet', '', true ); ?>
				<div class="ecg" aria-hidden="true"><svg viewBox="0 0 400 60" preserveAspectRatio="none"><path d="M0 34h70l12-22 14 44 14-40 10 18h60l12-22 14 44 14-40 10 18h166"/></svg></div>
				<figcaption><strong>Care team view</strong><span>Live patient insight</span></figcaption>
			</figure>
		</div>
	</div>
</section>

<div class="marquee" aria-hidden="true">
	<div class="marquee__track">
		<?php for ( $m = 0; $m < 2; $m++ ) : ?>
			<div class="marquee__group"><span>AI telehealth</span><span>Remote patient monitoring</span><span>Digital intake</span><span>HL7 and FHIR</span><span>AES-256 encryption</span><span>WCAG 2.1 accessible</span><span>Real-time analytics</span><span>Audit trails</span></div>
		<?php endfor; ?>
	</div>
</div>

<section class="section" aria-labelledby="svc-title">
	<div class="container">
		<div class="section-head reveal">
			<h2 id="svc-title">One platform for the whole patient journey</h2>
			<p class="lead">Start with the solution you need today. Each one connects to the others and to your EHR.</p>
		</div>
		<div class="bento stagger">
			<article class="bento__item b-a reveal">
				<?php clinix_img( 'mri-consult.jpg', 'Doctor showing brain scan results to a patient on a tablet' ); ?>
				<span class="ico"><?php clinix_icon( 'video', 24 ); ?></span>
				<h3>AI Telehealth Care</h3>
				<p>Secure video visits with an AI-prepared chart, live visit summaries and one-tap follow-up orders.</p>
				<a class="link-arrow" href="<?php echo esc_url( clinix_url( 'telehealth' ) ); ?>">Explore telehealth <?php clinix_icon( 'arrow', 16 ); ?></a>
			</article>
			<article class="bento__item b-b reveal">
				<span class="ico"><?php clinix_icon( 'activity', 24 ); ?></span>
				<h3 style="font-size:var(--fs-2)">Remote Patient Monitoring</h3>
				<p>Connected devices stream vitals and smart thresholds raise the alert.</p>
				<div class="mini-line" aria-hidden="true"><svg viewBox="0 0 300 70" preserveAspectRatio="none"><path d="M0 40h50l10-22 12 44 12-40 8 18h50l10-22 12 44 12-40 8 18h116"/></svg></div>
				<a class="link-arrow" href="<?php echo esc_url( clinix_url( 'rpm' ) ); ?>">Explore monitoring <?php clinix_icon( 'arrow', 16 ); ?></a>
			</article>
			<article class="bento__item b-c reveal">
				<span class="ico"><?php clinix_icon( 'clipboard', 24 ); ?></span>
				<h3 style="font-size:var(--fs-2)">Digital Intake Forms</h3>
				<p>Adaptive forms that patients finish on any device.</p>
				<div class="mini-form" aria-hidden="true"><span><?php clinix_icon( 'check', 14 ); ?> History</span><span><?php clinix_icon( 'check', 14 ); ?> Medications</span><span><?php clinix_icon( 'check', 14 ); ?> Consent</span></div>
				<a class="link-arrow" href="<?php echo esc_url( clinix_url( 'intake' ) ); ?>">Explore intake <?php clinix_icon( 'arrow', 16 ); ?></a>
			</article>
			<article class="bento__item b-d reveal">
				<span class="ico"><?php clinix_icon( 'link', 24 ); ?></span>
				<h3 style="font-size:var(--fs-2)">EHR sync that never lags</h3>
				<p>Two-way HL7 and FHIR sync keeps demographics, medications and notes current across every tool.</p>
				<a class="link-arrow" href="<?php echo esc_url( clinix_url( 'features' ) ); ?>">See all features <?php clinix_icon( 'arrow', 16 ); ?></a>
			</article>
			<article class="bento__item b-e reveal">
				<span class="ico"><?php clinix_icon( 'shield', 24 ); ?></span>
				<h3 style="font-size:var(--fs-2)">Security you can audit</h3>
				<p>Role-based access, multi-factor sign-in and immutable audit trails protect every record.</p>
				<a class="link-arrow" href="<?php echo esc_url( clinix_url( 'about' ) ); ?>">Our AI ethics <?php clinix_icon( 'arrow', 16 ); ?></a>
			</article>
		</div>
	</div>
</section>

<section class="section section--dark" aria-label="Platform at a glance">
	<div class="container">
		<div class="stats stagger">
			<div class="stat reveal"><b data-count="3">3</b><span>core solutions on one platform</span></div>
			<div class="stat reveal"><b><span data-count="24">24</span><em>/7</em></b><span>monitoring and alerting</span></div>
			<div class="stat reveal"><b data-count="256">256</b><span>bit AES encryption at rest</span></div>
			<div class="stat reveal"><b data-count="0">0</b><span>paper forms to retype</span></div>
		</div>
	</div>
</section>

<section class="section" aria-labelledby="agent-title">
	<div class="container split">
		<div class="reveal">
			<h2 id="agent-title">Meet the Clinix AI Agent</h2>
			<p class="lead">A built-in assistant that answers visitor questions instantly, using only the content on this website.</p>
			<ul class="ticks">
				<li><?php clinix_icon( 'check', 20 ); ?> Searches every page and article on the site.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Runs in the browser, so no question is sent to a third party.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Hands off to our admin on WhatsApp when it does not know the answer.</li>
			</ul>
			<button type="button" class="btn btn--mint" data-open-agent><?php clinix_icon( 'message', 18 ); ?> Ask the AI agent</button>
		</div>
		<div class="chat-mock glass reveal" aria-hidden="true">
			<div class="u">How does remote monitoring work?</div>
			<div class="b">Connected devices send readings to one dashboard. Smart thresholds alert your team when something changes.</div>
			<div class="u">Do you support my EHR?</div>
			<div class="b">We connect through HL7 and FHIR standards. Contact us to confirm your system.</div>
		</div>
	</div>
</section>

<section class="section section--canvas" aria-labelledby="how-title">
	<div class="container">
		<?php clinix_head( 'From first call to live in four steps', 'A clear path with our team beside yours at every stage.', false ); ?>
		<ol class="steps stagger">
			<li class="reveal"><h3>Discover</h3><p>We map your workflows, systems and goals in a short workshop.</p></li>
			<li class="reveal"><h3>Integrate</h3><p>We connect your EHR, devices and forms in a secure test environment.</p></li>
			<li class="reveal"><h3>Launch</h3><p>Your team is trained and the first patients go live with our support.</p></li>
			<li class="reveal"><h3>Optimise</h3><p>We review analytics together and tune alerts, forms and workflows.</p></li>
		</ol>
	</div>
</section>

<?php
get_template_part( 'template-parts/content', 'testimonials' );
get_template_part( 'template-parts/content', 'articles-latest' );
clinix_faq(
	array(
		array( 'What is Clinix AI?', 'Clinix AI is a HealthTech platform that combines AI telehealth, remote patient monitoring and digital intake forms, connected to your electronic health record.' ),
		array( 'How does the Clinix AI agent work?', 'The agent searches the content of this website directly in your browser and replies with the matching answer. If the answer is not on the site, it directs you to our admin.' ),
		array( 'Is patient data secure with Clinix AI?', 'Yes. Data is encrypted in transit and at rest, access is role-based, and every action is written to an audit trail. See the Features page for details.' ),
		array( 'How do I get started with Clinix AI?', 'Book a free demo using the contact form, call ' . clinix_opt( 'phone_display' ) . ' or message us on WhatsApp. We will map your workflow and propose a launch plan.' ),
	)
);
clinix_cta();
