<?php
/**
 * About Us sections.
 *
 * @package clinix-ai
 */
?>
<section class="section" aria-labelledby="vision-title">
	<div class="container split">
		<?php clinix_media( 'care-team.jpg', 'Two clinicians discussing results on a tablet in a bright clinic', 'Built with clinicians', 'Every workflow is reviewed by practising doctors and nurses.' ); ?>
		<div class="reveal">
			<h2 id="vision-title">Our vision</h2>
			<p class="lead">A world where every clinician has time to listen, and every patient is seen early.</p>
			<p>Clinix AI exists to remove the friction between people and care. We build tools that handle paperwork, surface risk and connect systems, so clinicians spend their energy on judgement and compassion.</p>
			<p>We design with working clinicians, test in real clinics and measure success by time returned to patients, not by features shipped.</p>
		</div>
	</div>
</section>

<section class="section section--dark" aria-labelledby="ethics-title">
	<div class="container">
		<div class="split" style="margin-bottom:clamp(2rem,5vw,3.5rem)">
			<div class="reveal">
				<h2 id="ethics-title">Medical AI ethics</h2>
				<p class="lead">AI supports clinical decisions. It never makes them alone.</p>
			</div>
			<?php clinix_media( 'brain-network.jpg', 'Glowing red illustration of a brain with connected neural pathways', 'AI that supports, never decides', 'Clinicians stay in control of every clinical decision.' ); ?>
		</div>
		<div class="grid grid--3">
			<div class="card card--dark reveal"><span class="ico"><?php clinix_icon( 'users', 24 ); ?></span><h3>Human in the loop</h3><p>Every AI suggestion is reviewed by a licensed clinician before it affects care.</p></div>
			<div class="card card--dark reveal"><span class="ico"><?php clinix_icon( 'eye', 24 ); ?></span><h3>Transparency</h3><p>Patients and staff can see when AI was used and what information it relied on.</p></div>
			<div class="card card--dark reveal"><span class="ico"><?php clinix_icon( 'lock', 24 ); ?></span><h3>Privacy by design</h3><p>We collect the minimum data needed and never sell patient information.</p></div>
			<div class="card card--dark reveal"><span class="ico"><?php clinix_icon( 'scale', 24 ); ?></span><h3>Fairness</h3><p>Models are tested across age, gender and background to reduce unequal outcomes.</p></div>
			<div class="card card--dark reveal"><span class="ico"><?php clinix_icon( 'shield', 24 ); ?></span><h3>Safety first</h3><p>Clear escalation paths send urgent cases to a person immediately.</p></div>
			<div class="card card--dark reveal"><span class="ico"><?php clinix_icon( 'clipboard', 24 ); ?></span><h3>Accountability</h3><p>Audit logs record who saw, changed or approved each AI-assisted action.</p></div>
		</div>
	</div>
</section>

<section class="section" aria-labelledby="team-title">
	<div class="container">
		<?php clinix_head( 'Our team', 'Clinicians, engineers and security specialists working as one group.', false ); ?>
		<div class="grid grid--4">
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'heart', 24 ); ?></span><h3>Clinical advisory board</h3><p>Practising doctors and nurses who review every workflow before launch.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'brain', 24 ); ?></span><h3>AI research</h3><p>Engineers who build, test and monitor our models for accuracy and bias.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'shield', 24 ); ?></span><h3>Security and compliance</h3><p>Specialists who run access reviews, penetration tests and audits.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'message', 24 ); ?></span><h3>Patient success</h3><p>A friendly support team that trains your staff and answers every question.</p></div>
		</div>
	</div>
</section>

<section class="section section--canvas" aria-labelledby="sec-title">
	<div class="container split">
		<div class="reveal">
			<h2 id="sec-title">Security and compliance</h2>
			<p class="lead">Trust is the product. These safeguards are built into every deployment.</p>
			<ul class="ticks">
				<li><?php clinix_icon( 'check', 20 ); ?> Encryption in transit (TLS) and at rest (AES-256).</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Role-based access control with multi-factor sign-in.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Complete audit trail of every record view and change.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> HIPAA-aligned processes and data processing agreements.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Regular third-party security testing and backups.</li>
			</ul>
		</div>
		<?php clinix_media( 'lab-team.jpg', 'Scientists in protective gear working in a bright laboratory', 'Rigorous by default', 'Regular testing and review keep models and security trustworthy.' ); ?>
	</div>
</section>
<?php
clinix_faq(
	array(
		array( 'Does Clinix AI replace doctors?', 'No. Clinix AI supports clinicians with summaries, alerts and automation. A licensed professional always makes the clinical decision.' ),
		array( 'Who can see patient data?', 'Only authorised users with the right role. Every view and change is recorded in an audit trail.' ),
	),
	'About Clinix AI: common questions'
);
clinix_cta();
