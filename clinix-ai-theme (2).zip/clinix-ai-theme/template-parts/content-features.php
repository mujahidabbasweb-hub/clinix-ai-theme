<?php
/**
 * Features deep dive.
 *
 * @package clinix-ai
 */
?>
<section class="section" aria-labelledby="sec-feat">
	<div class="container split">
		<div class="reveal">
			<h2 id="sec-feat">Platform security</h2>
			<p class="lead">Patient data is protected at every layer, from the device to the database.</p>
			<ul class="ticks">
				<li><?php clinix_icon( 'check', 20 ); ?> End-to-end encryption using TLS in transit and AES-256 at rest.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Multi-factor sign-in and role-based permissions for every user.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Immutable audit logs show who accessed or changed each record.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Automatic session timeout and device verification.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Encrypted backups with tested recovery procedures.</li>
			</ul>
		</div>
		<?php clinix_media( 'neural-hand.jpg', 'Robotic hand touching a glowing network of connected nodes', 'A secure, intelligent network', 'Every device and record connects through protected channels.' ); ?>
	</div>
</section>

<section class="section section--dark" aria-labelledby="an-feat">
	<div class="container split">
		<div class="dash glass reveal" role="img" aria-label="Sample analytics dashboard showing active patients, alerts and a rising trend line">
			<div class="dash__top"><span>Care overview</span><span class="dash__live"><span class="pulse"></span> Live</span></div>
			<div class="dash__kpis">
				<div><small>Patients</small><strong>1,284</strong></div>
				<div><small>Alerts</small><strong>7</strong></div>
				<div><small>On track</small><strong>94%</strong></div>
			</div>
			<div class="dash__chart">
				<svg viewBox="0 0 300 120" preserveAspectRatio="none" aria-hidden="true">
					<defs><linearGradient id="dg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#00FFC2" stop-opacity=".35"/><stop offset="1" stop-color="#00FFC2" stop-opacity="0"/></linearGradient></defs>
					<path class="area" d="M0 100 L30 84 L60 90 L90 62 L120 70 L150 46 L180 54 L210 32 L240 40 L270 18 L300 24 L300 120 L0 120Z"/>
					<path class="line" d="M0 100 L30 84 L60 90 L90 62 L120 70 L150 46 L180 54 L210 32 L240 40 L270 18 L300 24"/>
				</svg>
			</div>
		</div>
		<div class="reveal">
			<h2 id="an-feat">Real-time analytics</h2>
			<p class="lead">See which patients need attention now, and how your clinic is performing today.</p>
			<ul class="ticks">
				<li><?php clinix_icon( 'check', 20 ); ?> Live risk scores that rank patients by urgency.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Custom alert thresholds for each condition and patient.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Workload, wait-time and outcome reports for managers.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> One-click exports for audits and quality reviews.</li>
			</ul>
			<p style="font-size:.88rem">Dashboard values are illustrative.</p>
		</div>
	</div>
</section>

<section class="section" aria-labelledby="ehr-feat">
	<div class="container split split--flip">
		<div class="reveal">
			<h2 id="ehr-feat">EHR sync</h2>
			<p class="lead">Connect modern workflows to the systems you already run, old or new.</p>
			<ul class="ticks">
				<li><?php clinix_icon( 'check', 20 ); ?> Two-way sync using HL7 v2 and FHIR standards.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Demographics, medications, allergies and notes stay current.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Conflict handling that never overwrites clinician edits.</li>
				<li><?php clinix_icon( 'check', 20 ); ?> Support for legacy systems through secure gateways.</li>
			</ul>
		</div>
		<?php clinix_media( 'futuristic-clinic.jpg', 'Staff in white clothing beside vintage computer monitors on a dark stage', 'Legacy meets modern', 'Secure gateways connect older systems to today\'s workflows.' ); ?>
	</div>
</section>

<section class="section section--canvas" aria-labelledby="acc-feat">
	<div class="container">
		<?php clinix_head( 'Accessible for every patient', 'Our interfaces are built to meet WCAG 2.1 guidelines so more people can use them.', false ); ?>
		<div class="grid grid--3">
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'eye', 24 ); ?></span><h3>High contrast</h3><p>Text and controls use strong colour contrast and visible focus outlines.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'users', 24 ); ?></span><h3>Keyboard and screen reader ready</h3><p>Every action can be completed without a mouse and is announced clearly.</p></div>
			<div class="card reveal"><span class="ico"><?php clinix_icon( 'heart', 24 ); ?></span><h3>Calm and clear</h3><p>Reduced-motion support and plain language lower stress for anxious patients.</p></div>
		</div>
	</div>
</section>
<?php
clinix_faq(
	array(
		array( 'Which EHR systems does Clinix AI connect to?', 'Clinix AI connects through HL7 and FHIR standards, so it works with most modern EHRs. Contact us to confirm your specific system.' ),
		array( 'How is patient data encrypted?', 'Data is encrypted with TLS while moving and AES-256 while stored.' ),
		array( 'Does the platform meet accessibility standards?', 'The interface is designed to meet WCAG 2.1 guidelines, including keyboard access, contrast and screen-reader support.' ),
	)
);
clinix_cta();
